# Fishing Macro Mobile — decisão da base principal

## Base escolhida
A base selecionada é `fish_macro_v15` do workspace recebido em 21/10/2026. Esta pasta foi escolhida porque contém duas correções presentes em relação à árvore `fish_macro_project`:

1. Remove argumentos nomeados incompatíveis com o construtor de `PipelineInput` em `FischEngineService.kt`.
2. Implementa `cancelTimedPress()` em `input/GestureService.kt`, que era chamada sem definição na outra árvore.

## O que este pacote é
É uma consolidação limpa da árvore escolhida para continuar o trabalho: mantém código-fonte, recursos, testes, configuração Gradle, wrapper, documentação e testdata. Remove caches locais, diretórios de build, APKs antigos, ZIPs aninhados e credenciais de ambiente.

## Limitações conhecidas — não interpretar como validado
- A compilação completa e os testes Gradle ainda precisam ser executados em ambiente com Gradle 8.9, JDK compatível e Android SDK 35.
- `app/build.gradle.kts` ainda identifica o app como `versionCode = 12` e `versionName = "12.0-v12"`, apesar do nome V15 usado no projeto. A identidade de versão precisa ser alinhada antes de uma entrega final.
- O fluxo de captura e o botão flutuante ainda precisam ser reproduzidos no Galaxy A22; o log anterior só confirmava abertura da interface.
- A seleção desta árvore não significa que o problema de captura ou o input real estejam corrigidos.

## Próximos passos obrigatórios
1. Executar `./gradlew :core:test :core:selfTest :app:lintDebug :app:assembleDebug` em ambiente Android configurado.
2. Corrigir qualquer falha de compilação/teste encontrada; não ignorar falhas de self-test.
3. Alinhar `versionName`, versão exibida nos logs e documentação com o build efetivamente gerado.
4. Instalar o APK recém-compilado no Samsung SM-A225M e recolher o diagnóstico completo desde o toque em START, incluindo o bloco `[MEDIA_PROJECTION]` e stack trace.
