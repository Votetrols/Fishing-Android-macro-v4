# Fishing Macro Mobile — auditoria aprofundada do workspace completo

**Data:** 24/10/2026  
**Arquivo auditado:** `workspace-01a1381f-87d3-7b6b-9faf-886f804bb9d9.zip`  
**Objetivo:** avaliar integridade do pacote, consistência das cópias do código, capacidade de compilação, fluxo de captura MediaProjection, botão flutuante, input de 3 segundos, testes e riscos de entrega.

## 1. Resumo executivo

**Veredito: o workspace não está pronto para ser tratado como uma entrega validada.** O ZIP abre e passa na verificação de integridade, mas contém cópias divergentes do mesmo projeto. A cópia `fish_macro_project` — que também é a cópia embutida em `v15.zip` — tem pelo menos dois erros de compilação determinísticos encontrados por inspeção estática. A cópia `fish_macro_v15` contém as correções correspondentes a esses dois pontos, mas não foi possível comprovar que o projeto inteiro compila porque o Gradle 8.9 não está disponível localmente e a tentativa de baixá-lo falhou por ausência de DNS/rede.

Os documentos de versões anteriores não podem ser usados como prova de que este código compila: o próprio `docs/AUDIT_V12.md` registra 5 falhas na suíte JUnit, 25 falhas no self-test e informa que o build Android não foi validado após as alterações V12. O APK debug que acompanha o workspace pode ter sido compilado de uma revisão anterior; não há evidência suficiente no pacote para associá-lo de forma segura a uma das cópias atuais.

A ausência do botão flutuante após conceder a captura é compatível com uma falha antes de `prepareFishingSession()`: o botão só é pedido depois que a captura passa pelo primeiro frame e a sessão entra em READY. O diagnóstico anteriormente compartilhado, com apenas duas linhas `UI V6 aberta`, não identifica a etapa que falhou.

## 2. Escopo e integridade do pacote

| Verificação | Resultado | Evidência |
|---|---|---|
| Integridade do ZIP principal | **PASS** | 425 entradas; `unzip -t` terminou sem erros |
| Extração das fontes | **PASS** | As duas árvores principais puderam ser examinadas |
| Cópia `fish_macro_project` vs `v15.zip` interno | **Idênticas** nas fontes comparadas | 169 arquivos por árvore, excluindo caches/builds |
| Cópia `fish_macro_project` vs `fish_macro_v15` | **DIVERGENTE** | 2 arquivos de produção diferem |
| Execução real da suíte Gradle nesta sessão | **BLOQUEADA** | Wrapper tentou obter Gradle 8.9 e recebeu `UnknownHostException: services.gradle.org` |
| Build APK novo nesta sessão | **NÃO EXECUTADO** | Não foi possível iniciar o Gradle; SDK Android também não está configurado neste ambiente |
| Teste físico no Galaxy A22 | **NÃO EXECUTADO** | Não há dispositivo conectado a esta sessão |

O pacote contém, além das fontes, um APK debug, um APK release unsigned, `v15.zip`, `fischll_v13.zip`, logs de sondagem V9 e a pasta `.android` com arquivos de ambiente. Isso mistura código-fonte, artefatos antigos e dados locais que deveriam ficar fora de um pacote de entrega limpo.

## 3. Achados críticos

### C1 — `fish_macro_project` não compila: argumentos inexistentes em `PipelineInput`

**Arquivo:** `fish_macro_project/app/src/main/java/com/fischa/app/FischEngineService.kt`, linhas 1052–1060.

A chamada de `PipelineInput(...)` passa estes argumentos nomeados:

- `screenWidthPx`
- `screenHeightPx`
- `densityDpi`
- `rotationDeg`
- `appWindowWidthPx`
- `appWindowHeightPx`
- `statusBarPx`
- `navBarPx`

Porém, a classe `PipelineInput` em `core/src/main/kotlin/com/fischa/core/pipeline/PipelineEvent.kt`, linhas 10–24, não declara nenhum desses parâmetros. Kotlin não aceita argumentos nomeados que não existem no construtor. Isso é um **bloqueador de compilação**, independentemente de o Gradle conseguir ser executado.

A cópia `fish_macro_v15` não passa esses campos e, portanto, evita este erro específico. Antes de adicionar os campos ao construtor, é preciso confirmar que o pipeline realmente os consome: a implementação atual de `VisionPipeline` não contém uso desses parâmetros de geometria.

### C2 — `fish_macro_project` não compila: `cancelTimedPress()` é chamado mas não existe

**Arquivo:** `fish_macro_project/app/src/main/java/com/fischa/app/input/GestureService.kt`, linhas 149–153.

`holdRelease()` chama `cancelTimedPress()` quando `timedActive` é verdadeiro, mas a função não está definida nessa árvore. A pesquisa por `fun cancelTimedPress` nessa cópia não encontrou implementação. Isso também é um **bloqueador de compilação**.

A cópia `fish_macro_v15` inclui a função privada `cancelTimedPress()` (linhas 159–166), que marca o hold como cancelado e encaminha a liberação do gesto. Portanto, as duas cópias não são intercambiáveis: uma tem os argumentos extras inválidos; a outra tem a correção do cancelamento temporizado.

**Conclusão prática:** não compilar `fish_macro_project` nem o `v15.zip` embutido sem corrigir/mesclar esses pontos. `fish_macro_v15` é a melhor candidata entre as duas para continuar a investigação, mas ainda precisa de build completo; não afirmo que ela esteja livre de outros erros.

## 4. Cópias e versões incompatíveis

Foram encontradas três árvores de fontes relevantes:

1. `fish_macro_project/` — 169 arquivos de fonte/configuração comparados; contém os dois problemas acima.
2. `fish_macro_v15/` — mesma base geral, mas difere em `FischEngineService.kt` e `input/GestureService.kt`.
3. `v15.zip` — sua árvore `fish_macro_project/` é idêntica à cópia externa `fish_macro_project/`, inclusive com os dois problemas estáticos.

Também há divergência nos rótulos de versão:

- nome do APK: `FishingMacroMobile-v15-debug.apk`;
- `app/build.gradle.kts`: `versionCode = 12`, `versionName = "12.0-v12"`;
- log da Activity: `UI V6 aberta`;
- comentários e textos da interface referem-se a V6, V9.1 e outras etapas;
- documentação V6 antiga descreve `versionCode 4` e `versionName 0.4.0-a22`.

Isso não prova que o APK instalado no telefone seja uma versão específica, mas prova que **o workspace não possui uma identificação de versão única e confiável**. O nome do arquivo APK, sozinho, não confirma qual código está dentro dele.

## 5. Estado real dos testes e dos artefatos

### Tentativa executada nesta sessão

Comando tentado na cópia `fish_macro_project`:

```bash
bash gradlew --offline --no-daemon --console=plain :core:test :core:selfTest :app:assembleDebug
```

Resultado: o wrapper tentou baixar `https://services.gradle.org/distributions/gradle-8.9-bin.zip` e falhou com `java.net.UnknownHostException: services.gradle.org`. Portanto, **nenhum teste Gradle foi executado nesta tentativa e nenhum APK novo foi produzido**. O wrapper também não tem permissão de execução (`gradlew` está como modo 644 no pacote); para invocá-lo como `./gradlew`, o bit executável precisaria ser restaurado. `bash gradlew` contorna apenas o problema de permissão, não a falta do Gradle.

### Documentação de testes dentro do workspace

O documento `docs/AUDIT_V12.md` registra explicitamente:

- 242 testes coletados, 237 aprovados e 5 falharam;
- `:core:selfTest` com 25 falhas;
- build Android, lint, APK e teste físico não validados após V12 por falta de Android SDK.

Documentos V6/V7/V8 mais antigos relatam builds e números de testes anteriores. Esses resultados são históricos e não substituem a execução da versão atual. O próprio relatório V12 é mais recente e admite falhas e ausência de build Android.

### APKs presentes

- `FishingMacroMobile-v15-debug.apk` — presente no ZIP, tamanho 3.871.462 bytes.
- `FishingMacroMobile-v15-release-unsigned.apk` — presente, tamanho 3.029.064 bytes; o nome indica que é um release sem assinatura final.

Não foi possível validar a assinatura do APK com `apksigner`, porque a ferramenta não está instalada neste ambiente. Também não foi possível provar que o APK debug corresponde à cópia `fish_macro_v15` ou `fish_macro_project`. Trate os APKs como artefatos sem proveniência comprovada até que sejam recriados a partir de uma árvore única e identificada.

## 6. Fluxo START → permissão → captura → botão flutuante

A sequência estática implementada é:

1. `MainActivity.begin()` verifica se o serviço de Acessibilidade está conectado e salva os parâmetros.
2. `requestProjection()` abre o diálogo de consentimento do Android.
3. `onConsentResult()` verifica `resultCode`, `data` e o `MediaProjectionManager`, e inicia `FischEngineService`.
4. `startCaptureSession()` tenta iniciar o foreground service com tipo `mediaProjection` antes de `getMediaProjection()`.
5. O serviço registra `MediaProjection.Callback`, cria `ImageReader`, cria `VirtualDisplay` e aguarda o primeiro frame.
6. Só depois do relatório de captura bem-sucedido chama `prepareFishingSession()`.
7. `prepareFishingSession()` publica a geometria, marca a infraestrutura como pronta e pede ao `GameAccessibilityService` que mostre/atualize o botão flutuante.

Logo, **o botão não aparecer pode ser consequência de uma falha anterior na captura**, e não necessariamente um defeito no desenho do overlay. Se `CaptureDiagnostics.run()` falhar em uma etapa, o caminho encerra os recursos e chama `stopSelf()` antes de `prepareFishingSession()`.

O diagnóstico que contém apenas duas linhas `UI V6 aberta` corresponde ao log de `MainActivity.onResume()`. Ele não confirma que o resultado da permissão chegou, que o serviço iniciou, que `startForeground()` foi aceito, que `getMediaProjection()` funcionou, que o `VirtualDisplay` foi criado ou que houve primeiro frame. A causa específica do erro no Galaxy A22 continua **não comprovada sem o log completo da tentativa**.

## 7. Achados adicionais de implementação

### M1 — Espera do primeiro frame bloqueia a thread principal

`FischEngineService.onStartCommand()` chama `startCaptureSession()` de forma síncrona; esta executa `CaptureDiagnostics.run()`, cujo `awaitFirstFrame()` faz polling e `Thread.sleep(10)` até o primeiro frame ou timeout (configuração padrão: 2.500 ms). Como o serviço e a Activity compartilham o processo Android, esse trabalho ocupa a thread principal durante a espera. A captura pode continuar recebendo imagens no `HandlerThread`, mas a interface e a atualização visual ficam bloqueadas durante o período.

**Risco:** atraso perceptível e possibilidade de congelamento/ANR se a inicialização acumular outras demoras. Recomendação: mover a sequência de sondagem/espera para um executor de trabalho e publicar o resultado de volta na main thread, mantendo o `startForeground()` dentro do prazo exigido pelo Android.

### M2 — O campo `fps` do relatório de captura não mede FPS real

Na chamada a `CaptureDiagnostics.run()`, o serviço passa `capture?.effectiveFps`. Porém `ScreenCaptureSource.setRateLimit()` define `effectiveFps` como o limite configurado/clampado (`targetFps`), não como a taxa medida de frames recebidos. Assim, o relatório pode apresentar `fps > 0` porque o limite está configurado em 30 FPS, mesmo que a taxa real esteja muito abaixo disso.

O critério ainda exige frame age válido e pelo menos um frame recebido, o que ajuda, mas o campo FPS não é uma medição real. Para o diagnóstico ser confiável, deve usar uma taxa medida a partir de timestamps de frames recebidos/processados, ou rotular o valor atual como `targetFps`/`rateLimitFps`.

### M3 — Falha persistente de cópia pode gerar dois caminhos de erro

Em `ScreenCaptureSource.copyLatestImage()`, quando `acquireLatestImage()` falha 10 vezes, são chamados `onCaptureFailureDetailed(...)` e depois `onCaptureFailure(...)`. O serviço liga ambos a `handleCaptureFailure()`/`handleCaptureError()`, de modo que a mesma falha pode gerar dois tratamentos de erro e duas solicitações de encerramento. O bloco de falha durante `copyPixels()` também chama o callback detalhado e o callback genérico após o limiar.

**Risco:** log duplicado, transições repetidas e teardown concorrente desnecessário. Deve haver um único caminho terminal para cada falha persistente; o callback detalhado deve substituir, não duplicar, o genérico.

### M4 — Compartilhamento de diagnóstico pode truncar o final do log

`MainActivity.shareDiagnostics()` monta o relatório e aplica `.take(60_000)`. Isso mantém os primeiros 60.000 caracteres, não os últimos. Se o relatório ficar maior que esse limite, as mensagens mais recentes — possivelmente a exceção que precisamos — podem ser descartadas.

**Correção sugerida:** preservar o cabeçalho e o bloco de tentativa e reservar o restante do limite para o final do log, ou aplicar uma estratégia explícita de `takeLast` ao trecho de log.

### M5 — Serviço pode não ser parado em alguns erros antes de `running = true`

`stopEngine()` só chama `stopSelf()` quando `wasRunning` ou `emergencyStop` é verdadeiro. Há caminhos de falha durante preparação, antes de `prepareFishingSession()` definir `running=true`, que chamam `handleCaptureError()` → `stopEngine()` sem `emergencyStop`. Nesses caminhos, o serviço pode liberar foreground/recursos sem chamar `stopSelf()`.

O caminho principal de falha retornado por `CaptureDiagnostics.run()` chama `stopSelf()` explicitamente, então não afirmo que todo erro deixa o serviço vivo. O caso deve ser coberto por teste e corrigido para que qualquer falha terminal de uma sessão de inicialização pare o serviço de forma determinística.

### M6 — A remoção de Rod Detection está incompleta no código-fonte, embora o fluxo principal não o use

A implementação atual de `VisionPipeline` declara explicitamente que não há detector da vara, calibração nem transição baseada na vara; `runDetectors()` chama os detectores de SHAKE, barra e confirmação de captura de acordo com o estado. `SettingsActivity` também filtra chaves `rod.*`, `rodV7.*`, `rodV8.*` e `rodButtonV9.*` para não exibi-las ao usuário.

Entretanto, `AppConfig` ainda mantém os modelos e configurações V7/V8/V9, a chave `rodDetector`, parâmetros como `saveDiagnosticFrames = true`, e a árvore de testes inclui cenários V7/V8/V9. Portanto:

- se o requisito significa **não mostrar nem executar Rod Detection no fluxo ativo**, o pipeline atual aparenta respeitar isso;
- se o requisito significa **remover completamente o módulo legado do projeto**, isso ainda não foi feito.

Não recomendo apagar diretórios/classes às cegas antes de uma busca de referências e de testes, mas a documentação/escopo deve deixar claro qual das duas interpretações é a pretendida.

### M7 — O botão flutuante depende do serviço de Acessibilidade ativo

O controle usa `TYPE_ACCESSIBILITY_OVERLAY` e é criado pelo `GameAccessibilityService`, não por uma janela overlay genérica. `MainActivity.begin()` verifica a instância antes de pedir captura; se o serviço não estiver conectado ou se desconectar antes de READY, a chamada `GameAccessibilityService.instance?.updateFishingControl(...)` não consegue criar o botão. Isso é uma condição separada da permissão de captura e deve aparecer no diagnóstico como Acessibilidade ON/OFF.

### M8 — Dados locais sensíveis e excesso de artefatos no ZIP

O ZIP inclui `.android/adbkey` e `.android/adbkey.pub`, além de `.android/debug.keystore`, caches de SDK e APKs/ZIPs aninhados. A chave privada ADB é uma credencial de depuração e não deve ser distribuída junto com o projeto. Se o arquivo foi compartilhado fora de um ambiente confiável e essa chave foi autorizada no telefone, revogue as autorizações de depuração USB nas opções de desenvolvedor e gere uma chave nova. Não é necessário publicar nem copiar o conteúdo da chave para tratar o risco.

Para uma entrega limpa, manter apenas uma árvore-fonte autoritativa, Gradle wrapper, configurações, fontes, recursos, testes e documentação atual; excluir `.android/`, `.gradle/`, `.kotlin/`, SDK/cache local, APKs antigos, ZIPs aninhados e logs volumosos. Incluir um APK apenas quando ele tiver sido produzido pelo build final e identificado com hash e versão.

## 8. Input de 3 segundos e sequência de busca

O código atual contém `InitialPressController.DURATION_MS = 3000`, e `FishingStateMachine` documenta a transição `IDLE → INITIAL_PRESS → SEARCHING_SHAKE`. A pipeline registra a ação inicial como `hold 3000ms`; depois da confirmação de conclusão do gesto, a máquina entra na busca SHAKE. Isso corresponde, no desenho do código, à intenção de executar o pressionamento de 3 segundos antes de procurar o próximo sinal visual.

A validação é apenas estática nesta rodada. Não foi possível confirmar no Android que `dispatchGesture()` é aceito e concluído no aparelho. O input real também depende do opt-in `REAL_INPUT`, do serviço de Acessibilidade conectado, da autorização de foreground/Roblox e dos demais gates de segurança.

## 9. Prioridade de correção

1. **P0 — escolher uma única árvore e corrigir os dois bloqueadores estáticos** de `fish_macro_project`/`v15.zip` (parâmetros inexistentes e método `cancelTimedPress()` ausente).
2. **P0 — restaurar uma toolchain de build reproduzível** (Gradle 8.9, JDK compatível, Android SDK 35) e executar `:core:test`, `:core:selfTest`, `:app:lintDebug` e `:app:assembleDebug`. Não usar resultados históricos como substituto.
3. **P1 — alinhar a identidade da versão**: nome/versão do APK, `versionCode`, `versionName`, log de inicialização e relatório de build precisam identificar o mesmo commit/árvore.
4. **P1 — executar o diagnóstico de captura no Galaxy A22** e guardar o bloco completo `[MEDIA_PROJECTION]`, incluindo etapa da falha, exceção e stack trace. Isso é necessário para fechar a causa do botão ausente após o consentimento.
5. **P1 — corrigir a espera bloqueante e a medição de FPS** para que o diagnóstico represente a captura real e a UI não fique bloqueada durante a espera.
6. **P2 — unificar os callbacks de falha e testar o encerramento de serviço em falhas antes de READY**.
7. **P2 — corrigir truncamento do log compartilhado e limpar o pacote de entrega**, removendo dados locais/segredos e artefatos duplicados.
8. **P2 — decidir se Rod Detection deve apenas permanecer inativo ou ser removido por completo**, e ajustar fontes/documentação/testes de acordo.

## 10. Conclusão final

A integridade física do ZIP está boa, mas a integridade lógica da entrega não: há múltiplas cópias, rótulos de versão conflitantes, documentação de teste histórica, segredos de ambiente dentro do pacote e pelo menos uma árvore que tem dois erros estáticos de compilação. A cópia `fish_macro_v15` inclui as duas correções correspondentes, mas não foi possível validar a compilação integral nesta sessão.

**Não é correto afirmar que o workspace atual compila, que os testes passam ou que o problema do Galaxy A22 foi corrigido.** A causa exata da falha pós-permissão continua em aberto até existir um log que avance além de `UI V6 aberta`. A próxima validação confiável é: corrigir/escolher a árvore, fazer um build limpo, identificar o APK resultante por versão/hash e então reproduzir o START no A22 com o diagnóstico completo.
