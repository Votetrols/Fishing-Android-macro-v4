package com.fischa.app

import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.fischa.app.ui.DiagnosticsLog
import com.fischa.core.control.InputExecutor
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference

/** Normalized-coordinate adapter; only the AccessibilityService converts coordinates to pixels. */
class AndroidInputExecutor : InputExecutor {
    private val main = Handler(Looper.getMainLooper())
    @Volatile private var holdPostedAtMs = 0L
    private val postGraceMs = 250L

    override fun tap(nx: Float, ny: Float, durationMs: Int) {
        // No unauthenticated legacy path; production always uses the authorize-carrying overload.
    }

    override fun tap(nx: Float, ny: Float, durationMs: Int, authorize: () -> Boolean): Boolean =
        callOnMain("tap") { it.gestures.tap(nx, ny, durationMs, authorize) }

    override fun holdStart(nx: Float, ny: Float, leaseMs: Int, authorize: () -> Boolean): Boolean {
        holdPostedAtMs = SystemClock.uptimeMillis()
        val accepted = callOnMain("holdStart") { it.gestures.holdStart(nx, ny, leaseMs, authorize) }
        if (!accepted) holdPostedAtMs = 0L
        return accepted
    }

    override fun holdFor(
        nx: Float,
        ny: Float,
        durationMs: Int,
        authorize: () -> Boolean,
        onComplete: (Boolean) -> Unit,
    ): Boolean {
        holdPostedAtMs = SystemClock.uptimeMillis()
        val accepted = callOnMain("holdFor") {
            it.gestures.holdFor(nx, ny, durationMs, authorize) { success ->
                holdPostedAtMs = 0L
                onComplete(success)
            }
        }
        if (!accepted) holdPostedAtMs = 0L
        return accepted
    }

    override fun holdExtend(nx: Float, ny: Float, leaseMs: Int, authorize: () -> Boolean): Boolean =
        callOnMain("holdExtend") { it.gestures.holdExtend(nx, ny, leaseMs, authorize) }

    override fun holdRelease() {
        postToMain("holdRelease") { it.gestures.holdRelease(); true }
    }

    override fun cancelAll() {
        postToMain("cancelAll") { it.gestures.cancelAll(); true }
    }

    override fun cancelAll(onComplete: () -> Unit) {
        val service = GameAccessibilityService.instance
        if (service == null) {
            onComplete()
            return
        }
        if (Looper.myLooper() == Looper.getMainLooper()) {
            runCatching { service.gestures.cancelAll(onComplete) }
                .onFailure {
                    DiagnosticsLog.event("INPUT", "cancelAll cleanup exception: ${it.javaClass.simpleName}: ${it.message}")
                    onComplete()
                }
            return
        }
        val posted = main.post {
            val live = GameAccessibilityService.instance
            if (live == null) {
                onComplete()
            } else {
                runCatching { live.gestures.cancelAll(onComplete) }
                    .onFailure {
                        DiagnosticsLog.event("INPUT", "cancelAll cleanup exception: ${it.javaClass.simpleName}: ${it.message}")
                        onComplete()
                    }
            }
        }
        if (!posted) onComplete()
    }

    override fun releaseAll() = holdRelease()

    override fun activeGestureCount(): Int = GameAccessibilityService.instance?.gestures?.activeGestureCount ?: 0

    override fun holdStillActive(): Boolean? {
        val service = GameAccessibilityService.instance ?: return false
        if (service.gestures.activeGestureCount > 0) return true
        return holdPostedAtMs != 0L && SystemClock.uptimeMillis() - holdPostedAtMs < postGraceMs
    }

    /**
     * Off-main commands wait for the real `dispatchGesture` acceptance result, rather than treating
     * a successful Handler.post as successful game input. A timed-out post is invalidated and any
     * gesture already accepted on main is cancelled immediately afterwards.
     */
    private fun callOnMain(operation: String, block: (GameAccessibilityService) -> Boolean): Boolean {
        val service = GameAccessibilityService.instance ?: run {
            DiagnosticsLog.event("INPUT", "$operation refused: AccessibilityService is not connected")
            return false
        }
        if (Looper.myLooper() == Looper.getMainLooper()) return runCommand(operation, service, block)

        val finished = CountDownLatch(1)
        val cancelled = AtomicBoolean(false)
        val result = AtomicReference<Boolean?>(null)
        val posted = main.post {
            try {
                if (!cancelled.get() && GameAccessibilityService.instance === service) {
                    result.set(runCommand(operation, service, block))
                } else {
                    result.set(false)
                }
            } finally {
                finished.countDown()
            }
        }
        if (!posted) {
            DiagnosticsLog.event("INPUT", "$operation refused: main looper rejected work")
            return false
        }
        try {
            if (!finished.await(DISPATCH_ACCEPT_TIMEOUT_MS, TimeUnit.MILLISECONDS)) {
                cancelled.set(true)
                postToMain("timeout-cancel") { it.gestures.cancelAll(); true }
                DiagnosticsLog.event("INPUT", "$operation refused: platform dispatch acceptance timed out")
                return false
            }
        } catch (e: InterruptedException) {
            Thread.currentThread().interrupt()
            cancelled.set(true)
            postToMain("interrupt-cancel") { it.gestures.cancelAll(); true }
            DiagnosticsLog.event("INPUT", "$operation interrupted before platform acceptance")
            return false
        }
        return result.get() == true
    }

    private fun runCommand(
        operation: String,
        service: GameAccessibilityService,
        block: (GameAccessibilityService) -> Boolean,
    ): Boolean = try {
        block(service)
    } catch (e: Exception) {
        DiagnosticsLog.event("INPUT", "$operation failed: ${e.javaClass.simpleName}: ${e.message}")
        false
    }

    private fun postToMain(operation: String, block: (GameAccessibilityService) -> Boolean) {
        val posted = main.post {
            val service = GameAccessibilityService.instance ?: return@post
            runCommand(operation, service, block)
        }
        if (!posted) DiagnosticsLog.event("INPUT", "$operation cleanup could not be posted to main looper")
    }

    companion object {
        private const val DISPATCH_ACCEPT_TIMEOUT_MS = 1500L
    }
}
