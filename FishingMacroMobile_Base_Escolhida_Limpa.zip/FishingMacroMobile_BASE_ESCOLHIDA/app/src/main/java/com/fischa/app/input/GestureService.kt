package com.fischa.app.input

import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.os.Handler
import android.os.Looper
import android.os.SystemClock
import com.fischa.app.GameAccessibilityService
import com.fischa.app.InputGeometry
import com.fischa.app.ui.DiagnosticsLog
import com.fischa.core.common.CoordinateMapper
import com.fischa.core.config.AppConfig
import com.fischa.core.control.GestureLease
import com.fischa.core.control.GestureSessionState
import com.fischa.core.control.GestureTarget
import com.fischa.core.control.TimedPressPlan

/**
 * Main-looper adapter for Android's public AccessibilityService.dispatchGesture API.
 * Holds are finite continuations, and each continuation rechecks the live authorization closure.
 */
class GestureService(
    private val owner: GameAccessibilityService,
    cfg: AppConfig,
) {
    private val main = Handler(Looper.getMainLooper())
    private val quantumMs = cfg.safety.holdQuantumMs.coerceIn(30, 100)
    private val maxContinuousMs = cfg.safety.maxManualHoldMs.coerceIn(500, 10_000)
    private val lease = GestureLease(
        maxLeaseMs = cfg.safety.maxHoldLeaseMs.coerceIn(100, 500),
        maxContinuousMs = maxContinuousMs,
        watchdogMs = cfg.safety.watchdogMs.coerceIn(100, 1000),
    )

    private var stroke: GestureDescription.StrokeDescription? = null
    private var pixelX = 0f
    private var pixelY = 0f
    @Volatile private var inFlight = false
    @Volatile private var leaseActive = false
    @Volatile private var timedActive = false
    private var finishRequested = false
    @Volatile private var tapInFlight = false
    private var authorize: (() -> Boolean)? = null
    private var dispatchSerial = 0L
    private var timedPlan: TimedPressPlan? = null
    private var timedCompletion: ((Boolean) -> Unit)? = null
    private var timedCancelled = false
    private val cleanupCallbacks = ArrayList<() -> Unit>()

    val activeGestureCount: Int
        get() = if (inFlight || leaseActive || timedActive) 1 else 0

    fun tap(nx: Float, ny: Float, durationMs: Int, permit: () -> Boolean): Boolean {
        assertMainThread()
        if (!permitNow(permit) || inFlight || lease.state != GestureSessionState.IDLE || timedActive) return false
        val p = toPixels(nx, ny) ?: return false
        if (!lease.tap(GestureTarget(nx, ny), durationMs.toLong(), SystemClock.elapsedRealtime())) return false
        leaseActive = true
        pixelX = p.first
        pixelY = p.second
        authorize = permit
        tapInFlight = true
        DiagnosticsLog.event("INPUT", "TAP n=(${"%.3f".format(nx)},${"%.3f".format(ny)}) px=(${pixelX.toInt()},${pixelY.toInt()}) dur=${durationMs}ms")
        val path = Path().apply { moveTo(pixelX, pixelY) }
        val serial = ++dispatchSerial
        val desc = GestureDescription.StrokeDescription(path, 0L, durationMs.toLong())
        inFlight = true
        val accepted = dispatch(
            GestureDescription.Builder().addStroke(desc).build(),
            durationMs,
            serial,
            onCompleted = { clearGesture("tap completed") },
        )
        if (!accepted) clearGesture("tap rejected")
        return accepted
    }

    /** Start the existing frame-renewed hold lease used by the minigame controller. */
    fun holdStart(nx: Float, ny: Float, leaseMs: Int, permit: () -> Boolean): Boolean {
        assertMainThread()
        if (!permitNow(permit) || inFlight || lease.state != GestureSessionState.IDLE || timedActive) return false
        val p = toPixels(nx, ny) ?: return false
        if (!lease.holdStart(GestureTarget(nx, ny), leaseMs.toLong(), SystemClock.elapsedRealtime())) return false
        leaseActive = true
        pixelX = p.first
        pixelY = p.second
        authorize = permit
        finishRequested = false
        tapInFlight = false
        DiagnosticsLog.event("INPUT", "HOLD_START n=(${"%.3f".format(nx)},${"%.3f".format(ny)}) px=(${pixelX.toInt()},${pixelY.toInt()}) lease=${leaseMs}ms")
        sendHoldSegment()
        return lease.state == GestureSessionState.HOLD || inFlight
    }

    /**
     * Dispatch one fixed-length press. The initial action uses bounded continued strokes and a
     * monotonic deadline; completion is true only after Android completes the final release.
     */
    fun holdFor(
        nx: Float,
        ny: Float,
        durationMs: Int,
        permit: () -> Boolean,
        onComplete: (Boolean) -> Unit,
    ): Boolean {
        assertMainThread()
        if (durationMs !in 1..maxContinuousMs || !permitNow(permit) || inFlight ||
            lease.state != GestureSessionState.IDLE || timedActive
        ) return false
        val p = toPixels(nx, ny) ?: return false
        pixelX = p.first
        pixelY = p.second
        authorize = permit
        finishRequested = false
        timedCancelled = false
        tapInFlight = false
        timedPlan = TimedPressPlan(durationMs.toLong(), quantumMs.toLong()).apply {
            start(SystemClock.elapsedRealtime())
        }
        timedCompletion = onComplete
        timedActive = true
        DiagnosticsLog.event(
            "INPUT",
            "TIMED_HOLD start n=(${"%.3f".format(nx)},${"%.3f".format(ny)}) " +
                "px=(${pixelX.toInt()},${pixelY.toInt()}) duration=${durationMs}ms quantum=${quantumMs}ms",
        )
        val accepted = sendTimedSegment()
        if (!accepted && timedActive && !inFlight) clearGesture("timed hold rejected")
        return accepted
    }

    fun holdExtend(nx: Float, ny: Float, leaseMs: Int, permit: () -> Boolean): Boolean {
        assertMainThread()
        if (timedActive) return false
        if (!permitNow(permit)) {
            requestFinish("authorization expired before extend")
            return false
        }
        if (!lease.holdExtend(GestureTarget(nx, ny), leaseMs.toLong(), SystemClock.elapsedRealtime())) {
            requestFinish("invalid/expired hold renewal")
            return false
        }
        authorize = permit
        finishRequested = false
        if (!inFlight) sendHoldSegment()
        return true
    }

    fun holdRelease() {
        assertMainThread()
        if (timedActive) {
            cancelTimedPress()
            return
        }
        if (lease.state == GestureSessionState.HOLD) lease.holdRelease()
        requestFinish("hold released")
    }

    /** Cancel the fixed-duration press without waiting for its original deadline. */
    private fun cancelTimedPress() {
        assertMainThread()
        if (!timedActive) return
        timedCancelled = true
        finishRequested = true
        if (!inFlight) releaseTimedStroke(success = false)
    }

    fun cancelAll() = cancelAll { }

    /** Invoke [onComplete] only once the current finite stroke is released/cancelled. */
    fun cancelAll(onComplete: () -> Unit) {
        if (Looper.myLooper() != Looper.getMainLooper()) {
            if (!main.post { cancelAll(onComplete) }) runCatching { onComplete() }
            return
        }
        cleanupCallbacks.add(onComplete)
        lease.cancelAll()
        leaseActive = false
        finishRequested = true
        if (timedActive) {
            timedCancelled = true
            if (!inFlight) releaseTimedStroke(success = false)
            return
        }
        if (inFlight) return // the <=100ms segment callback performs the release path
        if (stroke != null) requestFinish("cancelAll") else clearGesture("cancelAll")
    }

    fun releaseAll() = holdRelease()

    private fun sendHoldSegment() {
        assertMainThread()
        if (inFlight || tapInFlight || lease.state != GestureSessionState.HOLD) return
        val now = SystemClock.elapsedRealtime()
        val currentPermit = authorize
        if (finishRequested || !lease.shouldContinue(now) || currentPermit?.let { permitNow(it) } != true) {
            requestFinish("watchdog/authorization blocked")
            return
        }
        val remaining = (lease.leaseDeadlineMs - now).coerceAtLeast(1L)
        val duration = minOf(quantumMs, remaining).coerceAtLeast(1L)
        val keep = remaining > duration && now - lease.startedAtMs + duration < maxContinuousMs
        val path = Path().apply { moveTo(pixelX, pixelY) }
        val next = try {
            stroke?.continueStroke(path, 0L, duration, keep)
                ?: GestureDescription.StrokeDescription(path, 0L, duration, keep)
        } catch (e: Exception) {
            clearGesture("continueStroke failed: ${e.message}")
            return
        }
        val serial = ++dispatchSerial
        inFlight = true
        val accepted = dispatch(
            GestureDescription.Builder().addStroke(next).build(),
            duration.toInt(),
            serial,
            onCompleted = {
                inFlight = false
                stroke = if (keep) next else null
                if (!keep) {
                    clearGesture("hold lease ended")
                } else if (finishRequested || !lease.shouldContinue(SystemClock.elapsedRealtime()) ||
                    authorize?.let { permitNow(it) } != true
                ) {
                    requestFinish("hold no longer authorized")
                } else {
                    sendHoldSegment()
                }
            },
        )
        if (!accepted) clearGesture("dispatchGesture rejected")
    }

    private fun sendTimedSegment(): Boolean {
        assertMainThread()
        val plan = timedPlan ?: return false
        if (inFlight) return true
        val currentPermit = authorize
        if (timedCancelled || finishRequested || currentPermit?.let { permitNow(it) } != true) {
            timedCancelled = true
            releaseTimedStroke(success = false)
            return false
        }
        val now = SystemClock.elapsedRealtime()
        val duration = plan.nextSegmentMs(now)
        if (duration == null) {
            releaseTimedStroke(success = plan.isComplete(now))
            return false
        }
        val deadline = plan.deadlineMs() ?: run {
            clearGesture("timed press has no deadline")
            return false
        }
        val keep = deadline - now > duration
        val path = Path().apply { moveTo(pixelX, pixelY) }
        val next = try {
            stroke?.continueStroke(path, 0L, duration, keep)
                ?: GestureDescription.StrokeDescription(path, 0L, duration, keep)
        } catch (e: Exception) {
            clearGesture("timed continueStroke failed: ${e.message}")
            return false
        }
        val serial = ++dispatchSerial
        inFlight = true
        val accepted = dispatch(
            GestureDescription.Builder().addStroke(next).build(),
            duration.toInt(),
            serial,
            onCompleted = {
                inFlight = false
                stroke = if (keep) next else null
                when {
                    timedCancelled || finishRequested -> releaseTimedStroke(success = false)
                    !keep -> finishTimedPress(
                        success = plan.isComplete(SystemClock.elapsedRealtime()),
                        reason = "timed press completed",
                    )
                    else -> sendTimedSegment()
                }
            },
        )
        if (!accepted) clearGesture("timed press dispatch rejected")
        return accepted
    }

    /** Ends the currently continued stroke with a 1ms final segment; never waits on the 3s plan. */
    private fun releaseTimedStroke(success: Boolean) {
        assertMainThread()
        if (!timedActive) return
        if (inFlight) return
        val activeStroke = stroke
        if (activeStroke == null) {
            finishTimedPress(success = success, reason = if (success) "timed press completed" else "timed press cancelled")
            return
        }
        val path = Path().apply { moveTo(pixelX, pixelY) }
        val close = try {
            activeStroke.continueStroke(path, 0L, 1L, false)
        } catch (e: Exception) {
            clearGesture("timed press release continuation failed: ${e.message}")
            return
        }
        val serial = ++dispatchSerial
        inFlight = true
        val accepted = dispatch(
            GestureDescription.Builder().addStroke(close).build(),
            1,
            serial,
            onCompleted = {
                stroke = null
                inFlight = false
                finishTimedPress(success = success && !timedCancelled, reason = "timed press released")
            },
        )
        if (!accepted) clearGesture("timed press release dispatch rejected")
    }

    private fun finishTimedPress(success: Boolean, reason: String) {
        val callback = timedCompletion
        timedCompletion = null
        timedPlan = null
        timedActive = false
        timedCancelled = false
        finishRequested = false
        stroke = null
        authorize = null
        inFlight = false
        tapInFlight = false
        leaseActive = false
        if (reason.isNotBlank()) DiagnosticsLog.event("INPUT", reason)
        runCatching { callback?.invoke(success) }
        runCleanupCallbacks()
    }

    private fun requestFinish(reason: String) {
        if (timedActive) {
            timedCancelled = true
            finishRequested = true
            if (!inFlight) releaseTimedStroke(success = false)
            return
        }
        finishRequested = true
        if (inFlight) return
        val activeStroke = stroke
        if (activeStroke == null) {
            clearGesture(reason)
            return
        }
        val path = Path().apply { moveTo(pixelX, pixelY) }
        val close = try {
            activeStroke.continueStroke(path, 0L, 1L, false)
        } catch (e: Exception) {
            clearGesture("release continuation failed: ${e.message}")
            return
        }
        val serial = ++dispatchSerial
        inFlight = true
        val accepted = dispatch(
            GestureDescription.Builder().addStroke(close).build(),
            1,
            serial,
            onCompleted = { clearGesture(reason) },
        )
        if (!accepted) clearGesture("release dispatch rejected")
    }

    private fun dispatch(
        gesture: GestureDescription,
        durationMs: Int,
        serial: Long,
        onCompleted: () -> Unit,
    ): Boolean {
        val accepted = try {
            owner.dispatchGesture(
                gesture,
                object : android.accessibilityservice.AccessibilityService.GestureResultCallback() {
                    override fun onCompleted(gestureDescription: GestureDescription?) {
                        if (serial != dispatchSerial) return
                        onCompleted()
                    }

                    override fun onCancelled(gestureDescription: GestureDescription?) {
                        if (serial != dispatchSerial) return
                        clearGesture("Android cancelled gesture")
                    }
                },
                main,
            )
        } catch (e: Exception) {
            DiagnosticsLog.event("INPUT", "dispatchGesture exception: ${e.message}")
            false
        }
        if (!accepted) return false
        val expected = serial
        main.postDelayed({
            if (inFlight && dispatchSerial == expected) {
                DiagnosticsLog.event("INPUT", "gesture watchdog expired after ${durationMs}ms")
                inFlight = false
                when {
                    timedActive && stroke != null -> {
                        timedCancelled = true
                        releaseTimedStroke(success = false)
                    }
                    timedActive -> clearGesture("timed press callback watchdog")
                    tapInFlight -> clearGesture("tap watchdog")
                    stroke != null || lease.state == GestureSessionState.HOLD -> requestFinish("hold watchdog")
                    else -> clearGesture("gesture watchdog")
                }
            }
        }, durationMs.coerceAtLeast(1) + 250L)
        return true
    }

    /** NORMALIZED → device pixels through the mapper published by the active capture session. */
    private fun toPixels(nx: Float, ny: Float): Pair<Float, Float>? {
        if (!CoordinateMapper.isValidNormalized(nx, ny)) return null
        val mapper = InputGeometry.mapper
        if (mapper == null) {
            DiagnosticsLog.event("INPUT", "gesture refused: no capture geometry published")
            return null
        }
        val p = mapper.normalizedToDevice(nx, ny) ?: return null
        return p.x to p.y
    }

    private fun clearGesture(reason: String) {
        val callback = timedCompletion
        val hadTimedPress = timedPlan != null || callback != null
        if (tapInFlight) lease.completeTap() else lease.holdRelease()
        leaseActive = false
        timedPlan = null
        timedCompletion = null
        timedActive = false
        timedCancelled = false
        stroke = null
        authorize = null
        finishRequested = false
        inFlight = false
        tapInFlight = false
        if (reason.isNotBlank()) DiagnosticsLog.event("INPUT", reason)
        if (hadTimedPress) runCatching { callback?.invoke(false) }
        runCleanupCallbacks()
    }

    private fun runCleanupCallbacks() {
        if (cleanupCallbacks.isEmpty()) return
        val callbacks = ArrayList(cleanupCallbacks)
        cleanupCallbacks.clear()
        callbacks.forEach { runCatching { it() } }
    }

    private fun permitNow(permit: () -> Boolean): Boolean = try {
        owner.refreshForegroundStatus().inputAuthorized && permit()
    } catch (_: Exception) {
        false
    }

    private fun assertMainThread() {
        check(Looper.myLooper() == Looper.getMainLooper()) { "GestureService must be mutated on main looper" }
    }
}
