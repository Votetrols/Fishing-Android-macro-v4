package com.fischa.core.control

/**
 * Platform-neutral schedule for one fixed-duration accessibility press. The final segment is
 * shortened so segment durations sum to exactly [durationMs]. Callers use a monotonic clock.
 */
class TimedPressPlan(
    val durationMs: Long = DEFAULT_DURATION_MS,
    private val quantumMs: Long = DEFAULT_QUANTUM_MS,
) {
    init {
        require(durationMs > 0L)
        require(quantumMs > 0L)
    }

    private var startedAtMs: Long? = null
    private var nextDeadlineMs: Long? = null

    fun start(nowMs: Long) {
        require(nowMs >= 0L)
        startedAtMs = nowMs
        nextDeadlineMs = nowMs + durationMs
    }

    fun startedAtMs(): Long? = startedAtMs
    fun deadlineMs(): Long? = nextDeadlineMs

    /** Length for the next segment, or null once the exact deadline has been reached. */
    fun nextSegmentMs(nowMs: Long): Long? {
        val deadline = nextDeadlineMs ?: return null
        val remaining = deadline - nowMs
        return if (remaining <= 0L) null else minOf(quantumMs, remaining)
    }

    fun isComplete(nowMs: Long): Boolean = nextDeadlineMs?.let { nowMs >= it } ?: false

    fun reset() {
        startedAtMs = null
        nextDeadlineMs = null
    }

    companion object {
        const val DEFAULT_DURATION_MS = 3000L
        const val DEFAULT_QUANTUM_MS = 65L
    }
}

/** One-shot lifecycle; success comes only from the platform's completed-gesture callback. */
class InitialPressController {
    companion object {
        const val DURATION_MS = 3000
        const val DURATION_NS = DURATION_MS * 1_000_000L
    }

    enum class Phase { IDLE, READY, RUNNING, COMPLETE, FAILED }

    var phase: Phase = Phase.IDLE
        private set

    val complete: Boolean get() = phase == Phase.COMPLETE
    val failed: Boolean get() = phase == Phase.FAILED
    val shouldDispatch: Boolean get() = phase == Phase.READY

    fun startSession() {
        phase = Phase.READY
    }

    fun markDispatchAccepted() {
        if (phase == Phase.READY) phase = Phase.RUNNING
    }

    fun markDispatchRejected() {
        if (phase == Phase.READY || phase == Phase.RUNNING) phase = Phase.FAILED
    }

    fun onPlatformCompleted(success: Boolean) {
        if (phase == Phase.RUNNING) phase = if (success) Phase.COMPLETE else Phase.FAILED
    }

    fun reset() {
        phase = Phase.IDLE
    }
}
