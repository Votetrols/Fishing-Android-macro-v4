package com.fischa.core.pipeline

import com.fischa.core.common.clamp
import com.fischa.core.config.AppConfig
import com.fischa.core.control.ControlAction
import com.fischa.core.control.FishingController
import com.fischa.core.control.GestureTarget
import com.fischa.core.control.InitialPressController
import com.fischa.core.control.InputExecutor
import com.fischa.core.control.ShakeController
import com.fischa.core.debug.RenderModel
import com.fischa.core.log.Tags
import com.fischa.core.log.ThrottledLog
import com.fischa.core.safety.DenyReason
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.GestureAction
import com.fischa.core.safety.InputRequest
import com.fischa.core.safety.InputSafetyGuard
import com.fischa.core.safety.RobloxForegroundStatus
import com.fischa.core.safety.SafetyContext
import com.fischa.core.state.AutomationState
import com.fischa.core.state.AutomationStateMachine
import com.fischa.core.state.Evidence
import com.fischa.core.state.FishingState
import com.fischa.core.state.FishingStateMachine
import com.fischa.core.tracking.BarTracker
import com.fischa.core.tracking.ConfidenceTracker
import com.fischa.core.tracking.FishTracker
import com.fischa.core.tracking.PlayerBarTracker
import com.fischa.core.tracking.ProgressTracker
import com.fischa.core.vision.CatchConfirmDetector
import com.fischa.core.vision.DetSnapshot
import com.fischa.core.vision.FishDetector
import com.fischa.core.vision.FishingBarDetector
import com.fischa.core.vision.PlayerBarDetector
import com.fischa.core.vision.ProgressDetector
import com.fischa.core.vision.ShakeDetector
import com.fischa.core.vision.VisionFrame
import java.util.concurrent.atomic.AtomicLong
import java.util.concurrent.atomic.AtomicReference
import kotlin.math.max
import kotlin.math.min

/**
 * Pipeline for START FISHING → fixed 3000ms press → visual SHAKE search → minigame control.
 * Android/Roblox access remains behind [InputExecutor] and [InputSafetyGuard]. No rod detector,
 * calibration, or rod-based transition is part of this pipeline.
 */
class VisionPipeline(
    val cfg: AppConfig,
    private val executor: InputExecutor,
    private val log: ThrottledLog,
    val safety: SafetyContext = SafetyContext(),
    val emergency: EmergencyStop = EmergencyStop(),
    private val foregroundStatusProvider: (() -> RobloxForegroundStatus?)? = null,
    private val monotonicNowNs: () -> Long = { System.nanoTime() },
) : AutoCloseable {
    private val shakeDetector = ShakeDetector(cfg.vision)
    private val barDetector = FishingBarDetector(cfg.vision)
    private val blockDetector = PlayerBarDetector(cfg.vision)
    private val fishDetector = FishDetector(cfg.vision)
    private val progressDetector = ProgressDetector(cfg.vision)
    private val catchDetector = CatchConfirmDetector(cfg.vision)

    private val barTracker = BarTracker(cfg.tracking)
    private val fishTracker = FishTracker(cfg.tracking)
    private val blockTracker = PlayerBarTracker(cfg.tracking)
    private val progressTracker = ProgressTracker()
    private val confTracker = ConfidenceTracker(cfg.tracking)
    private val barRect = floatArrayOf(0f, 0f, 0f, 0f)

    private val stateMachine = FishingStateMachine(cfg.state)
    private val shakeController = ShakeController(cfg.shake)
    private val initialPressController = InitialPressController()
    private val controller = FishingController(cfg.control)
    private val guard = InputSafetyGuard(cfg.safety)
    private val evidence = Evidence()

    val output = PipelineOutput()
    val automation = AutomationStateMachine(clockNs = { monotonicNowNs() })
    val automationState: AutomationState get() = automation.state
    var armed: Boolean
        get() = automation.pumping
        set(value) { if (value) startFishing() else stopFishing() }

    @Volatile var lastFps: Float = 0f
    @Volatile var render: RenderModel? = null
        private set
    @Volatile private var holdActive = false
    @Volatile private var realGestureActive = false
    private var holdTarget: GestureTarget? = null
    @Volatile private var holdAnchorOverride: GestureTarget? = null
    private var lastActionName = ControlAction.NONE
    private var lastFrameNs = 0L
    private var lastInputLogNs = 0L
    /** Frame-thread-owned lifecycle marker; UI actions only advance [sessionGeneration]. */
    private var observedSessionGeneration = Long.MIN_VALUE
    private var inactiveSessionCleared = false

    /** Callback is written from the Android main thread and consumed by the frame thread. */
    private data class PressCompletion(val generation: Long, val success: Boolean)
    private val sessionGeneration = AtomicLong(0L)
    private val pressCompletion = AtomicReference<PressCompletion?>(null)

    private fun normBox(src: DetSnapshot, width: Int, height: Int): FloatArray? {
        if (!src.detected || width <= 0 || height <= 0) return null
        return floatArrayOf(src.box.left / width, src.box.top / height, src.box.right / width, src.box.bottom / height)
    }

    fun setHoldAnchor(nx: Float, ny: Float) {
        holdAnchorOverride = if (nx.isFinite() && ny.isFinite() && nx in 0f..1f && ny in 0f..1f) {
            GestureTarget(nx, ny)
        } else null
    }

    private val emergencyListener: () -> Unit = {
        // Invalidate before posting cleanup, so queued main-thread work cannot begin a stale input.
        sessionGeneration.incrementAndGet()
        pressCompletion.set(null)
        realGestureActive = false
        holdActive = false
        holdTarget = null
        automation.emergency(emergency.lastReason.ifBlank { "emergency stop" }, monotonicNowNs())
        applyAutomationGate()
        runCatching { executor.cancelAll() }
    }

    init { emergency.addListener(emergencyListener) }

    private fun clearSnapshot(snapshot: DetSnapshot, frameNs: Long) {
        snapshot.detected = false
        snapshot.confidence = 0f
        snapshot.rawScore = 0f
        snapshot.box.set(0f, 0f, 0f, 0f)
        snapshot.timestampNs = frameNs
        snapshot.v0 = 0f; snapshot.v1 = 0f; snapshot.v2 = 0f; snapshot.v3 = 0f
        snapshot.streak = 0
        snapshot.lostFrames = 0
    }

    private fun resetDetectors() {
        shakeDetector.reset()
        barDetector.reset()
        blockDetector.reset()
        fishDetector.reset()
        progressDetector.reset()
        catchDetector.reset()
        barTracker.reset()
        fishTracker.reset()
        blockTracker.reset()
        progressTracker.reset()
        confTracker.reset()
        barRect.fill(0f)
        lastFrameNs = 0L
    }

    /**
     * State/detector objects are frame-thread confined. START/STOP only change the generation and
     * cancel platform input; this worker performs the corresponding reset on its next frame.
     */
    private fun synchronizeSessionOnFrame(frameNs: Long, generation: Long) {
        if (generation == observedSessionGeneration) return
        observedSessionGeneration = generation
        if (!automation.pumping) return
        resetDetectors()
        shakeController.resetSession()
        initialPressController.reset()
        controller.reset()
        catchDetector.reset()
        holdActive = false
        realGestureActive = false
        holdTarget = null
        holdAnchorOverride = null
        safety.lastInputNs = 0L
        stateMachine.disarm(frameNs, "new START FISHING session")
        stateMachine.armed = true
        inactiveSessionCleared = false
        lastActionName = ControlAction.NONE
        log.i(Tags.SYSTEM, "session", "[AUTOMATION] new session reset on frame worker; no rod detection")
    }

    private fun pollPressCompletion() {
        val result = pressCompletion.getAndSet(null) ?: return
        if (result.generation != sessionGeneration.get()) return
        initialPressController.onPlatformCompleted(result.success)
        realGestureActive = false
        holdActive = false
        holdTarget = null
        if (!result.success) {
            log.w(Tags.INPUT, "initial-press", "[INPUT] initial 3000ms press was cancelled/refused by Android")
        } else {
            log.i(Tags.INPUT, "initial-press", "[INPUT] initial press completed by AccessibilityService (3000ms)")
        }
    }

    /** READY/STOPPING fast path: no pixel conversion, detectors, trackers, or stale input. */
    private fun publishAutomationInactive(frame: VisionFrame, input: PipelineInput, frameNs: Long, ageMs: Long, startedNs: Long) {
        clearSnapshot(output.shake, frameNs)
        clearSnapshot(output.bar, frameNs)
        clearSnapshot(output.player, frameNs)
        clearSnapshot(output.fish, frameNs)
        clearSnapshot(output.progress, frameNs)
        clearSnapshot(output.catchConfirm, frameNs)
        if (!inactiveSessionCleared) {
            resetDetectors()
            shakeController.resetSession()
            initialPressController.reset()
            stateMachine.disarm(frameNs, "automação inativa")
            inactiveSessionCleared = true
        }
        output.state = FishingState.IDLE
        output.stateReason = "automação inativa (${automation.state.name})"
        output.automationState = automation.state
        output.automationLine = automation.debugLine
        output.automationReason = automation.lastReason
        output.fishXNorm = 0f; output.playerXNorm = 0f; output.errorNorm = 0f
        output.fishVel = 0f; output.playerVel = 0f; output.desiredVel = 0f
        output.progressValue = 0f; output.progressRate = 0f; output.globalConfidence = 0f
        output.frameAgeMs = ageMs
        output.intendedAction = ControlAction.NONE
        output.tapDurationMs = 0
        output.holdActive = false
        output.decisionReason = output.stateReason
        output.inputIssued = false
        output.inputDeniedReason = DenyReason.AUTOMATION_NOT_ACTIVE.name
        output.inputAuthorized = false
        output.realInputEnabled = input.realInputEnabled
        output.robloxDetected = input.robloxDetected
        output.foregroundPackage = input.foregroundPackage
        output.foregroundActivityWindow = input.foregroundActivityWindow
        output.foregroundBlockReason = input.foregroundBlockReason
        output.emergencyLatched = emergency.latched
        output.armed = false
        output.shakeSessionTaps = 0
        output.shakeSession = 0
        output.initialPressPhase = initialPressController.phase.name
        output.barRectPx.fill(0f)
        output.barLocked = false
        output.blockCenterPx = -1f
        output.fishCenterPx = -1f
        output.layerVision = "IDLE"
        output.layerDetection = "IDLE"
        output.layerDecision = "IDLE"
        output.layerInput = "DISABLED"
        safety.trackingOk = false
        safety.state = FishingState.IDLE
        render = RenderModel(
            state = FishingState.IDLE,
            automationLine = automation.debugLine,
            automationState = automation.state.name,
            automationReason = automation.lastReason,
            fps = lastFps,
            procMs = (monotonicNowNs() - startedNs) / 1e6f,
            barBox = null, blockBox = null, fishBox = null, shakeBox = null, progressBox = null,
            fishCx = 0f, playerCx = 0f, error = 0f, fishVel = 0f, playerVel = 0f, desiredVel = 0f,
            action = ControlAction.NONE.name, actionReason = output.stateReason,
            progress = 0f, progressRate = 0f, confGlobal = 0f, confBar = 0f,
            confFish = 0f, confPlayer = 0f, confShake = 0f,
            holdActive = false, tapsThisSession = 0, shakeSession = 0,
            denyReason = DenyReason.AUTOMATION_NOT_ACTIVE.name, emergency = emergency.latched,
            armed = false, robloxDetected = input.robloxDetected,
            foregroundPackage = input.foregroundPackage, foregroundWindow = input.foregroundActivityWindow,
            inputAuthorized = false, realInputEnabled = input.realInputEnabled, frameAgeMs = ageMs,
            safetyBlockedReason = DenyReason.AUTOMATION_NOT_ACTIVE.name,
            layerVision = "IDLE", layerDetection = "IDLE", layerDecision = "IDLE", layerInput = "DISABLED",
        )
    }

    fun onFrame(frame: VisionFrame, input: PipelineInput) {
        val startedNs = monotonicNowNs()
        val frameNs = frame.timestampNs
        val nowNs = input.currentTimeNs.takeIf { it > 0L } ?: frameNs
        val ageMs = if (frameNs <= 0L || nowNs < frameNs) Long.MAX_VALUE else (nowNs - frameNs) / 1_000_000L
        log.setNow(frameNs)
        val frameGeneration = sessionGeneration.get()
        synchronizeSessionOnFrame(frameNs, frameGeneration)
        pollPressCompletion()
        if (realGestureActive && !holdActive && executor.activeGestureCount() == 0) {
            realGestureActive = false
        }

        safety.automationActive = automation.pumping
        safety.macroEnabled = automation.pumping && input.macroEnabled
        safety.realInputEnabled = input.realInputEnabled
        safety.captureHealthy = input.captureHealthy
        safety.robloxDetected = input.robloxDetected
        safety.platformAuthorized = input.inputAuthorized
        safety.overlaySuspected = input.overlaySuspected
        safety.frameTimestampNs = frameNs
        safety.state = stateMachine.state

        if (!automation.pumping) {
            if (realGestureActive) releaseActiveGesture(cancel = true)
            publishAutomationInactive(frame, input, frameNs, ageMs, startedNs)
            return
        }
        inactiveSessionCleared = false

        if ((!input.inputAuthorized || !input.captureHealthy || !safety.macroEnabled ||
                !input.realInputEnabled || emergency.latched) && realGestureActive
        ) releaseActiveGesture(cancel = true)

        frame.ensureGray()
        val width = frame.width
        val height = frame.height
        runDetectors(frame)
        // STOP/restart may race this expensive frame. Never let its old evidence dispatch input.
        if (frameGeneration != sessionGeneration.get()) return

        if (!automation.pumping) {
            if (realGestureActive) releaseActiveGesture(cancel = true)
            publishAutomationInactive(frame, input, frameNs, ageMs, startedNs)
            return
        }

        val stateBeforeUpdate = stateMachine.state
        val controlVisionActive = stateBeforeUpdate.controlling
        val barDetected = barDetector.out.detected
        val barLocked = controlVisionActive && barDetected && barTracker.update(
            barDetector.geometry.left, barDetector.geometry.top,
            barDetector.geometry.right, barDetector.geometry.bottom,
            max(barDetector.out.confidence, 0.6f), barRect,
        )
        if (barLocked) barTracker.touch(frameNs)
        val barWidth = max(1f, barRect[2] - barRect[0])

        if (controlVisionActive) {
            if (barLocked) {
                blockDetector.setBarPrior(barRect[0], barRect[1], barRect[2], barRect[3])
                fishDetector.setBarPrior(barRect[0], barRect[1], barRect[2], barRect[3])
                progressDetector.setBarPrior(barRect[0], barRect[1], barRect[2], barRect[3])
            } else {
                blockDetector.clearBarPrior()
                fishDetector.clearBarPrior()
                progressDetector.clearBarPrior()
            }
            blockDetector.process(frame)
            if (barLocked && blockDetector.out.detected) {
                fishDetector.blockL = blockDetector.geom.left.toInt()
                fishDetector.blockR = blockDetector.geom.right.toInt()
            } else {
                fishDetector.blockL = -1
                fishDetector.blockR = -1
            }
            fishDetector.priorXNorm = if (fishTracker.out.valid) fishTracker.out.x else -1f
            fishDetector.process(frame)
            progressDetector.process(frame)
        } else {
            blockDetector.reset(); fishDetector.reset(); progressDetector.reset()
            barTracker.reset(); blockTracker.reset(); fishTracker.reset(); progressTracker.reset()
            barRect.fill(0f)
        }

        if (controlVisionActive && barLocked) {
            if (blockDetector.out.detected) {
                blockTracker.update(
                    frameNs,
                    (blockDetector.geom.centerX - barRect[0]) / barWidth,
                    blockDetector.geom.width / barWidth,
                    blockDetector.out.confidence,
                    blockDetector.out.v0 > 0.5f,
                    barRect[0], barRect[2], blockDetector.geom.left, blockDetector.geom.right,
                )
            } else blockTracker.update(frameNs, null, 0f, 0f, false, barRect[0], barRect[2], 0f, 0f)

            if (fishDetector.out.detected) {
                fishTracker.update(frameNs, fishDetector.out.v0, fishDetector.out.confidence, barWidth)
            } else fishTracker.update(frameNs, null, 0f, barWidth)
        }
        if (controlVisionActive) {
            progressTracker.update(
                frameNs,
                if (progressDetector.out.detected) progressDetector.out.v0 else null,
                progressDetector.out.confidence,
            )
            confTracker.update(barDetector.out.confidence, fishTracker.out.confidence, blockTracker.out.confidence, frameNs)
        } else confTracker.reset()

        safety.trackingOk = controlVisionActive && fishTracker.out.valid && !fishTracker.out.lost &&
            blockTracker.out.valid && !blockTracker.out.lost &&
            fishTracker.out.confidence >= cfg.control.minConfidence &&
            blockTracker.out.confidence >= cfg.control.minConfidence

        evidence.shake = shakeDetector.out.detected
        evidence.shakeConf = shakeDetector.out.confidence
        evidence.shakeGone = shakeController.phase == ShakeController.Phase.SEARCHING && !shakeDetector.out.detected
        evidence.bar = barDetector.out.detected
        evidence.barConf = barDetector.out.confidence
        evidence.fishOk = fishTracker.out.valid && !fishTracker.out.lost
        evidence.playerOk = blockTracker.out.valid && !blockTracker.out.lost
        evidence.progress = progressTracker.value
        evidence.catchConfirm = catchDetector.out.detected
        evidence.catchConfirmConf = catchDetector.out.confidence
        evidence.robloxForeground = input.inputAuthorized && input.robloxDetected
        evidence.captureHealthy = input.captureHealthy
        evidence.overlaySuspected = input.overlaySuspected
        evidence.globalConf = confTracker.global
        evidence.initialPressComplete = initialPressController.complete
        evidence.initialPressFailed = initialPressController.failed
        evidence.nowNs = frameNs
        evidence.dtSec = if (lastFrameNs == 0L) 1f / 30f else clamp((frameNs - lastFrameNs) / 1e9f, 0.001f, 0.25f)
        lastFrameNs = frameNs

        val oldState = stateMachine.state
        safety.automationActive = automation.pumping
        safety.macroEnabled = automation.pumping && input.macroEnabled
        stateMachine.armed = safety.macroEnabled
        stateMachine.update(evidence)
        val state = stateMachine.state
        safety.state = state
        if (frameGeneration != sessionGeneration.get()) return
        if (!automation.pumping) {
            if (realGestureActive) releaseActiveGesture(cancel = true)
            publishAutomationInactive(frame, input, frameNs, ageMs, startedNs)
            return
        }
        if (state != oldState) {
            log.i(Tags.STATE, "state", "[STATE] ${oldState.name} -> ${state.name} (${stateMachine.lastReason})")
            if ((oldState == FishingState.INITIAL_PRESS && state != FishingState.INITIAL_PRESS && !initialPressController.complete) ||
                (oldState.isMinigame() && !state.isMinigame()) || state.isError
            ) releaseActiveGesture(cancel = state.isError)
            onStateEntry(state, frameNs)
        }

        var request: InputRequest? = null
        var reason = ""
        var intendedAction = ControlAction.NONE
        var reportedDurationMs = 0
        var initialHoldRequest = false

        if (state == FishingState.INITIAL_PRESS && initialPressController.shouldDispatch) {
            val x = cfg.initialPress.x
            val y = cfg.initialPress.y
            safety.controllerSafe = x.isFinite() && y.isFinite() && x in 0f..1f && y in 0f..1f
            reason = "fixed initial hold ${InitialPressController.DURATION_MS}ms"
            request = InputRequest(
                action = GestureAction.HOLD_START,
                nx = x,
                ny = y,
                durationMs = cfg.safety.maxHoldLeaseMs,
                confidence = 1f,
                reason = reason,
            )
            initialHoldRequest = true
            intendedAction = ControlAction.HOLD_START
            reportedDurationMs = InitialPressController.DURATION_MS
        }

        if (stateMachine.shakePhaseActive()) {
            val cx = if (shakeDetector.out.detected) shakeDetector.out.box.centerX / width else -1f
            val cy = if (shakeDetector.out.detected) shakeDetector.out.box.centerY / height else -1f
            val tap = shakeController.tick(shakeDetector.out.detected, shakeDetector.out.confidence, cx, cy, frameNs)
            if (tap != null) {
                reason = tap.reason
                reportedDurationMs = tap.durMs
                intendedAction = ControlAction.TAP
                safety.controllerSafe = shakeDetector.out.detected && shakeDetector.out.confidence.isFinite() &&
                    shakeDetector.out.confidence >= cfg.shake.minConfidence &&
                    tap.nx.isFinite() && tap.nx in 0f..1f && tap.ny.isFinite() && tap.ny in 0f..1f &&
                    tap.durMs.toLong() in 1L..cfg.safety.maxTapMs
                request = InputRequest(
                    GestureAction.TAP, tap.nx, tap.ny, tap.durMs.toLong(),
                    shakeDetector.out.confidence, tap.reason,
                )
            }
        }

        if (barLocked && state.controlling) {
            val decision = controller.update(frameNs, evidence.dtSec, fishTracker.out, blockTracker.out, progressTracker.rate)
            safety.controllerSafe = decision.safe
            intendedAction = decision.action
            reason = decision.reason
            output.errorNorm = decision.error
            output.fishVel = decision.fishVel
            output.playerVel = decision.playerVel
            output.desiredVel = decision.desiredVel
            val target = holdAnchorOverride ?: GestureTarget(
                ((barRect[0] + barRect[2]) * 0.5f / width).coerceIn(0f, 1f),
                ((barRect[1] + barRect[3]) * 0.5f / height).coerceIn(0f, 1f),
            )
            val confidence = minOf(fishTracker.out.confidence, blockTracker.out.confidence)
            when (decision.action) {
                ControlAction.TAP -> {
                    request = InputRequest(GestureAction.TAP, target.x, target.y, decision.tapDurMs.toLong(), confidence, decision.reason)
                    reportedDurationMs = decision.tapDurMs
                }
                ControlAction.HOLD_START -> {
                    holdTarget = target
                    request = InputRequest(GestureAction.HOLD_START, target.x, target.y, cfg.safety.maxHoldLeaseMs, confidence, decision.reason)
                    reportedDurationMs = cfg.safety.maxHoldLeaseMs.toInt()
                }
                ControlAction.HOLD_EXTEND -> {
                    val activeTarget = holdTarget ?: target.also { holdTarget = it }
                    request = InputRequest(GestureAction.HOLD_EXTEND, activeTarget.x, activeTarget.y, cfg.safety.maxHoldLeaseMs, confidence, decision.reason)
                    reportedDurationMs = cfg.safety.maxHoldLeaseMs.toInt()
                }
                ControlAction.HOLD_RELEASE -> {
                    holdActive = false
                    request = InputRequest(GestureAction.HOLD_RELEASE, reason = decision.reason)
                }
                ControlAction.NONE -> Unit
            }
            lastActionName = decision.action
        } else {
            if (holdActive && !state.isMinigame() && state != FishingState.INITIAL_PRESS) {
                holdActive = false
                request = InputRequest(GestureAction.HOLD_RELEASE, reason = "state no longer permits hold")
            }
            if (!state.isMinigame()) {
                controller.reset()
                lastActionName = ControlAction.NONE
                output.errorNorm = 0f; output.fishVel = 0f; output.playerVel = 0f; output.desiredVel = 0f
            }
        }

        if (emergency.latched || !input.captureHealthy || !input.inputAuthorized || !safety.macroEnabled ||
            !input.realInputEnabled
        ) {
            if (realGestureActive) request = InputRequest(GestureAction.CANCEL_ALL, reason = "safety context lost")
        }

        safety.automationActive = automation.pumping
        safety.macroEnabled = automation.pumping && input.macroEnabled
        if (!automation.pumping && request != null && request?.action != GestureAction.HOLD_RELEASE &&
            request?.action != GestureAction.CANCEL_ALL
        ) request = if (realGestureActive) InputRequest(GestureAction.CANCEL_ALL, reason = "STOP priority") else null

        var denied = DenyReason.OK
        var issued = false
        request?.let { original ->
            if (original.action == GestureAction.HOLD_RELEASE || original.action == GestureAction.CANCEL_ALL) {
                if (original.action == GestureAction.CANCEL_ALL) executor.cancelAll() else executor.holdRelease()
                realGestureActive = false; holdActive = false; holdTarget = null
            } else {
                safety.targetConfidence = original.confidence
                val verdict = guard.evaluate(safety, original, nowNs, emergency)
                if (!verdict.allowed) {
                    denied = verdict.reason
                    if (initialHoldRequest) initialPressController.markDispatchRejected()
                    if (state.controlling && (original.action == GestureAction.HOLD_START || original.action == GestureAction.HOLD_EXTEND)) {
                        controller.reset(); holdActive = false; holdTarget = null
                    }
                    log.w(Tags.SAFETY, "deny", "[SAFETY] INPUT BLOCKED reason=${verdict.reason.name} package=${input.foregroundPackage} frameAge=${ageMs}ms")
                    if (realGestureActive) releaseActiveGesture(cancel = true)
                } else if (!input.realInputEnabled) {
                    denied = DenyReason.REAL_INPUT_DISABLED
                    if (initialHoldRequest) initialPressController.markDispatchRejected()
                } else {
                    val generation = sessionGeneration.get()
                    val authorizeSegment = {
                        if (generation != sessionGeneration.get()) false else {
                            safety.automationActive = automation.pumping
                            safety.macroEnabled = automation.pumping && input.macroEnabled
                            refreshPlatformSafety()
                            safety.targetConfidence = original.confidence
                            val liveNow = monotonicNowNs()
                            generation == sessionGeneration.get() && automation.pumping &&
                                guard.evaluate(safety, original, liveNow, emergency).allowed
                        }
                    }
                    // Move to RUNNING before entering the adapter; a fast platform callback must
                    // never be lost in the small interval before holdFor returns.
                    if (initialHoldRequest) initialPressController.markDispatchAccepted()
                    val accepted = when (original.action) {
                        GestureAction.TAP -> executor.tap(original.nx, original.ny, original.durationMs.toInt(), authorizeSegment)
                        GestureAction.HOLD_START -> if (initialHoldRequest) {
                            executor.holdFor(
                                original.nx, original.ny, InitialPressController.DURATION_MS, authorizeSegment,
                            ) { success ->
                                if (generation == sessionGeneration.get()) pressCompletion.set(PressCompletion(generation, success))
                            }
                        } else executor.holdStart(original.nx, original.ny, original.durationMs.toInt(), authorizeSegment)
                        GestureAction.HOLD_EXTEND -> executor.holdExtend(original.nx, original.ny, original.durationMs.toInt(), authorizeSegment)
                        else -> false
                    }
                    if (generation != sessionGeneration.get() || !automation.pumping) {
                        if (accepted) runCatching { executor.cancelAll() }
                        return
                    }
                    if (accepted) {
                        issued = true
                        if (initialHoldRequest) {
                            realGestureActive = true
                            holdActive = true
                            holdTarget = GestureTarget(original.nx, original.ny)
                        } else if (original.action == GestureAction.HOLD_START || original.action == GestureAction.HOLD_EXTEND) {
                            realGestureActive = true; holdActive = true
                            holdTarget = GestureTarget(original.nx, original.ny)
                        } else if (original.action == GestureAction.TAP) {
                            realGestureActive = true
                            lastActionName = ControlAction.TAP
                        }
                        safety.lastInputNs = nowNs
                        log.i(Tags.INPUT, "gesture", "[INPUT] ${if (initialHoldRequest) "TIMED_HOLD" else original.action.name} " +
                            "x=${"%.3f".format(original.nx)} y=${"%.3f".format(original.ny)} " +
                            "duration=${if (initialHoldRequest) InitialPressController.DURATION_MS else original.durationMs}ms")
                    } else {
                        denied = DenyReason.INVALID_COMMAND
                        if (initialHoldRequest) initialPressController.markDispatchRejected()
                        if (state.controlling && (original.action == GestureAction.HOLD_START || original.action == GestureAction.HOLD_EXTEND)) {
                            controller.reset(); holdActive = false; holdTarget = null
                        }
                        if (original.action == GestureAction.HOLD_START || original.action == GestureAction.HOLD_EXTEND) realGestureActive = false
                        log.w(Tags.INPUT, "dispatch", "[INPUT] AccessibilityService recusou o gesto")
                    }
                }
            }
        }

        if (ageMs > cfg.safety.maxFrameAgeMs && denied == DenyReason.OK && request != null) denied = DenyReason.FRAME_STALE
        val safetyBasePass = safety.macroEnabled && safety.realInputEnabled && safety.captureHealthy &&
            safety.robloxDetected && safety.platformAuthorized && !safety.overlaySuspected &&
            !emergency.latched && ageMs in 0..cfg.safety.maxFrameAgeMs

        with(output) {
            shake.copyFrom(shakeDetector.out)
            bar.copyFrom(barDetector.out)
            player.copyFrom(blockDetector.out)
            fish.copyFrom(fishDetector.out)
            progress.copyFrom(progressDetector.out)
            catchConfirm.copyFrom(catchDetector.out)
            this.state = state
            this.stateReason = stateMachine.lastReason
            this.fishXNorm = fishTracker.out.x
            this.playerXNorm = blockTracker.out.x
            this.progressValue = max(0f, progressTracker.value)
            this.progressRate = progressTracker.rate
            this.globalConfidence = confTracker.global
            this.frameAgeMs = ageMs
            this.intendedAction = intendedAction
            this.tapDurationMs = reportedDurationMs
            this.holdActive = holdActive
            this.decisionReason = reason
            this.inputIssued = issued
            this.inputDeniedReason = if (denied == DenyReason.OK) "" else denied.name
            this.inputAuthorized = safetyBasePass
            this.realInputEnabled = safety.realInputEnabled
            this.robloxDetected = input.robloxDetected
            this.foregroundPackage = input.foregroundPackage
            this.foregroundActivityWindow = input.foregroundActivityWindow
            this.foregroundBlockReason = input.foregroundBlockReason
            this.emergencyLatched = emergency.latched
            this.armed = safety.macroEnabled
            this.automationState = automation.state
            this.automationReason = automation.lastReason
            this.automationLine = automation.debugLine
            this.shakeSessionTaps = shakeController.tapsThisSession
            this.shakeSession = stateMachine.shakeSession
            this.initialPressPhase = initialPressController.phase.name
            this.barRectPx[0] = barRect[0]; this.barRectPx[1] = barRect[1]
            this.barRectPx[2] = barRect[2]; this.barRectPx[3] = barRect[3]
            this.barLocked = barLocked
            this.blockCenterPx = if (blockDetector.out.detected) blockDetector.geom.centerX else -1f
            this.fishCenterPx = if (fishDetector.out.detected) (fishDetector.out.box.left + fishDetector.out.box.right) * 0.5f else -1f
            this.layerVision = if (state == FishingState.INITIAL_PRESS) "INITIAL_PRESS" else "ACTIVE"
            this.layerDetection = if (state == FishingState.SEARCHING_SHAKE || state == FishingState.PRESSING_SHAKE) "SHAKE" else "STATE_GATED"
            this.layerDecision = if (safety.macroEnabled) "ACTIVE" else "IDLE"
            this.layerInput = if (safety.realInputEnabled) "ENABLED" else "DISABLED"
        }

        render = RenderModel(
            state = state,
            automationLine = automation.debugLine,
            automationState = automation.state.name,
            automationReason = automation.lastReason,
            fps = lastFps,
            procMs = (monotonicNowNs() - startedNs) / 1e6f,
            barBox = if (barLocked) floatArrayOf(barRect[0] / width, barRect[1] / height, barRect[2] / width, barRect[3] / height) else null,
            blockBox = normBox(blockDetector.out, width, height),
            fishBox = normBox(fishDetector.out, width, height),
            shakeBox = normBox(shakeDetector.out, width, height),
            progressBox = normBox(progressDetector.out, width, height),
            fishCx = fishTracker.out.x, playerCx = blockTracker.out.x,
            error = output.errorNorm, fishVel = output.fishVel, playerVel = output.playerVel,
            desiredVel = output.desiredVel, action = lastActionName.name, actionReason = reason,
            progress = output.progressValue, progressRate = output.progressRate,
            confGlobal = confTracker.global, confBar = confTracker.bar,
            confFish = confTracker.fish, confPlayer = confTracker.player,
            confShake = shakeDetector.out.confidence, holdActive = holdActive,
            tapsThisSession = shakeController.tapsThisSession, shakeSession = stateMachine.shakeSession,
            denyReason = if (denied == DenyReason.OK) "" else denied.name,
            emergency = emergency.latched, armed = safety.macroEnabled,
            robloxDetected = input.robloxDetected, foregroundPackage = input.foregroundPackage,
            foregroundWindow = input.foregroundActivityWindow, inputAuthorized = safetyBasePass,
            realInputEnabled = safety.realInputEnabled, frameAgeMs = ageMs,
            safetyBlockedReason = when {
                denied != DenyReason.OK -> denied.name
                !safety.realInputEnabled -> "REAL_INPUT_DISABLED"
                !safetyBasePass -> input.foregroundBlockReason
                else -> "PASS"
            },
            layerVision = output.layerVision, layerDetection = output.layerDetection,
            layerDecision = output.layerDecision, layerInput = output.layerInput,
        )

        if (frameNs - lastInputLogNs >= 1_000_000_000L || lastInputLogNs == 0L) {
            lastInputLogNs = frameNs
            log.i(Tags.STATE, "watch", "[STATE] ${state.name} SHAKE=${shakeDetector.out.detected} " +
                "bar=${barDetector.out.detected} action=${request?.action ?: intendedAction} " +
                "input=${if (issued) "EXECUTED" else denied.name} realInput=${input.realInputEnabled}")
            log.i(Tags.SAFETY, "snapshot", "[SAFETY] pkg=${input.foregroundPackage} " +
                "roblox=${input.robloxDetected} authorized=$safetyBasePass block=${input.foregroundBlockReason} " +
                "frameAge=${ageMs}ms state=${state.name}")
            log.i(Tags.CONTROL, "decision", "[CONTROL] state=${state.name} error=${"%+.3f".format(output.errorNorm)} " +
                "action=${request?.action ?: intendedAction} reason=$reason")
        }
    }

    private fun runDetectors(frame: VisionFrame) {
        val state = stateMachine.state
        if (state == FishingState.SEARCHING_SHAKE || state == FishingState.PRESSING_SHAKE) {
            shakeDetector.process(frame)
            barDetector.process(frame)
        } else {
            shakeDetector.reset()
            if (state == FishingState.FISHING_MINIGAME_DETECTED || state.controlling) barDetector.process(frame)
            else barDetector.reset()
        }
        if (state == FishingState.CATCH_CONFIRMATION) catchDetector.process(frame) else catchDetector.reset()
    }

    private fun refreshPlatformSafety() {
        // JVM/replay hosts pass platform facts in PipelineInput; Android supplies the live provider.
        val provider = foregroundStatusProvider ?: return
        val status = runCatching { provider.invoke() }.getOrNull()
        if (status == null) {
            safety.robloxDetected = false
            safety.platformAuthorized = false
            safety.overlaySuspected = true
            return
        }
        safety.robloxDetected = status.robloxDetected
        safety.platformAuthorized = status.inputAuthorized
        safety.overlaySuspected = status.overlayActive
    }

    private fun releaseActiveGesture(cancel: Boolean) {
        if (cancel) runCatching { executor.cancelAll() }
        else runCatching { executor.holdRelease() }
        realGestureActive = false
        holdActive = false
        holdTarget = null
    }

    private fun onStateEntry(state: FishingState, nowNs: Long) {
        when (state) {
            FishingState.INITIAL_PRESS -> {
                initialPressController.startSession()
                pressCompletion.set(null)
                shakeController.resetSession()
                controller.reset()
                log.i(Tags.INPUT, "initial-press", "[INPUT] iniciando press fixo de ${InitialPressController.DURATION_MS}ms")
            }
            FishingState.SEARCHING_SHAKE -> shakeController.resetSession()
            FishingState.FISHING_MINIGAME_DETECTED -> {
                controller.reset(); holdActive = false
                fishTracker.reset(); blockTracker.reset(); progressTracker.reset()
            }
            FishingState.RESET -> {
                shakeController.resetSession(); controller.reset(); holdActive = false; catchDetector.reset()
            }
            FishingState.VISION_LOST,
            FishingState.CAPTURE_ERROR,
            FishingState.ROBLOX_NOT_DETECTED,
            FishingState.INPUT_ERROR,
            FishingState.INVALID_STATE,
            FishingState.EMERGENCY_STOP -> {
                releaseActiveGesture(cancel = true)
                controller.reset(); fishTracker.reset(); blockTracker.reset()
            }
            else -> Unit
        }
    }

    fun setFpsMeasured(fps: Float) { lastFps = fps }

    // ---- Automation lifecycle -------------------------------------------------------------
    fun setInfrastructureReady(
        ready: Boolean,
        reason: String = if (ready) "captura RUNNING" else "infraestrutura encerrada",
        nowNs: Long = monotonicNowNs(),
    ): Boolean {
        val change = automation.setInfrastructureReady(ready, reason, nowNs)
        applyAutomationGate()
        if (ready) {
            if (change != null) log.i(Tags.SYSTEM, "automation", "[AUTOMATION] READY ($reason)")
        } else {
            invalidateAndCancel()
        }
        return change != null
    }

    fun startFishing(reason: String = "START FISHING", nowNs: Long = monotonicNowNs()): Boolean {
        val change = automation.startFishing(reason, nowNs)
        if (change == null) {
            log.i(Tags.SYSTEM, "automation", "[AUTOMATION] $reason ignorado (estado ${automation.state.name})")
            return false
        }
        // A generation change invalidates every delayed callback/segment from the prior run.
        sessionGeneration.incrementAndGet()
        pressCompletion.set(null)
        realGestureActive = false
        holdActive = false
        holdTarget = null
        applyAutomationGate()
        log.i(Tags.SYSTEM, "automation", "[AUTOMATION] START FISHING aceito; primeira ação = hold 3000ms")
        return true
    }

    /** STOP is immediate at the gate; READY is published only after executor cleanup completes. */
    fun stopFishing(
        reason: String = "STOP",
        nowNs: Long = monotonicNowNs(),
        onCleanupComplete: (() -> Unit)? = null,
    ): Boolean {
        val stopping = automation.requestStop(reason, nowNs) ?: return false
        applyAutomationGate()
        val stopGeneration = sessionGeneration.incrementAndGet()
        pressCompletion.set(null)
        realGestureActive = false
        holdActive = false
        holdTarget = null
        try {
            executor.cancelAll {
                if (sessionGeneration.get() == stopGeneration && automation.state == AutomationState.FISHING_STOPPING) {
                    automation.completeStop("input cleanup complete", monotonicNowNs())
                    applyAutomationGate()
                    log.i(Tags.SYSTEM, "automation", "[AUTOMATION] STOP cleanup complete; READY")
                    try {
                        onCleanupComplete?.invoke()
                    } catch (t: Throwable) {
                        log.e(Tags.INPUT, "stop-callback", "[INPUT] STOP completion callback failed: ${t.javaClass.simpleName}: ${t.message}")
                    }
                }
            }
        } catch (t: Throwable) {
            // Do not falsely publish READY or run teardown callbacks if platform cleanup failed.
            log.e(Tags.INPUT, "stop-cleanup", "[INPUT] STOP cleanup failed: ${t.javaClass.simpleName}: ${t.message}")
        }
        log.i(Tags.SYSTEM, "automation", "[AUTOMATION] ${stopping.from.name} -> STOPPING ($reason)")
        return true
    }

    fun disarm(nowNs: Long, reason: String = "sessão encerrada") {
        automation.emergency(reason, nowNs)
        applyAutomationGate()
        invalidateAndCancel()
        log.i(Tags.SYSTEM, "disarm", "[SYSTEM] macro disarmed at $nowNs ($reason)")
    }

    private fun applyAutomationGate() {
        safety.automationActive = automation.pumping
        safety.macroEnabled = automation.pumping
    }

    private fun invalidateAndCancel() {
        sessionGeneration.incrementAndGet()
        pressCompletion.set(null)
        realGestureActive = false
        holdActive = false
        holdTarget = null
        runCatching { executor.cancelAll() }
    }

    override fun close() {
        disarm(monotonicNowNs(), "pipeline.close")
        emergency.removeListener(emergencyListener)
    }

    private fun FishingState.isMinigame() = controlling
}
