package com.fischa.core.safety

/**
 * Fail-closed session gate for genuine Android input.
 *
 * A user opt-in alone is insufficient: real gestures are enabled only when the session was
 * explicitly authorized and the user-enabled AccessibilityService is connected. Actual touch
 * dispatch still goes through Android's public AccessibilityService.dispatchGesture API, and each
 * bounded gesture segment is re-authorized by InputSafetyGuard. This is not a privilege bypass.
 */
object RealInputPolicy {
    fun allows(sessionAuthorized: Boolean, accessibilityServiceConnected: Boolean): Boolean =
        sessionAuthorized && accessibilityServiceConnected
}
