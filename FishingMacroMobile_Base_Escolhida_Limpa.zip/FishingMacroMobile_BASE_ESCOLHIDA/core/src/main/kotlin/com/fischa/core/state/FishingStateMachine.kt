package com.fischa.core.state

import com.fischa.core.config.AppConfig
import kotlin.math.max
import kotlin.math.min

/** Reusable per-frame evidence bundle. */
class Evidence {
    var shake = false
    var shakeConf = 0f
    var shakeGone = false
    var bar = false
    var barConf = 0f
    var fishOk = false
    var playerOk = false
    var progress = -1f
    var catchConfirm = false
    var catchConfirmConf = 0f
    var robloxForeground = false
    var captureHealthy = false
    var overlaySuspected = false
    var globalConf = 0f
    var nowNs = 0L
    var dtSec = 1f / 30f
    var initialPressComplete = false
    var initialPressFailed = false
}

/**
 * Fishing cycle:
 * IDLE → INITIAL_PRESS (exactly 3000ms) → SEARCHING_SHAKE ⇄ PRESSING_SHAKE →
 * minigame control → RESET → INITIAL_PRESS.
 *
 * The state machine never sends Android input. `initialPressComplete` is supplied only by the
 * platform executor's completion callback; a configured mode or queued command is not success.
 */
class FishingStateMachine(private val cfg: AppConfig.StateTiming) {
    var state = FishingState.IDLE
        private set
    var enteredAtNs = 0L
        private set
    var lastReason = "init"
        private set

    /** Set by the host on START FISHING and cleared immediately on STOP. */
    var armed = false
    var shakeSession = 0
        private set
    var globalConfFloor = 0.28f

    private val listeners = ArrayList<(StateChange) -> Unit>()
    fun addListener(l: (StateChange) -> Unit) { synchronized(listeners) { listeners.add(l) } }
    fun removeListener(l: (StateChange) -> Unit) { synchronized(listeners) { listeners.remove(l) } }

    private var barStreak = 0
    private var barLostStreak = 0
    private var noEvidenceSince = -1L
    private var nonRobloxSince = -1L
    private var catchConfirmed = false
    private var catchClearFrames = 0

    private fun enter(next: FishingState, nowNs: Long, reason: String) {
        if (state == next) return
        val previous = state
        if (next == FishingState.IDLE) clearTransient()
        if (next == FishingState.CATCH_CONFIRMATION) {
            catchConfirmed = false
            catchClearFrames = 0
        } else if (next == FishingState.RESET && previous != FishingState.CATCH_CONFIRMATION) {
            catchConfirmed = false
            catchClearFrames = 0
        }
        state = next
        enteredAtNs = nowNs
        lastReason = reason
        val copy = synchronized(listeners) { ArrayList(listeners) }
        copy.forEach { runCatching { it(StateChange(previous, next, reason, nowNs)) } }
    }

    fun disarm(nowNs: Long, reason: String = "sessão encerrada pelo host") {
        armed = false
        if (state != FishingState.IDLE) enter(FishingState.IDLE, nowNs, reason)
    }

    fun resetAll(nowNs: Long) = enter(FishingState.RESET, nowNs, "manual reset")
    fun emergencyStop(nowNs: Long) = enter(FishingState.EMERGENCY_STOP, nowNs, "emergency stop")

    fun shakePhaseActive(): Boolean =
        state == FishingState.SEARCHING_SHAKE || state == FishingState.PRESSING_SHAKE

    private fun clearTransient() {
        barStreak = 0
        barLostStreak = 0
        noEvidenceSince = -1L
        nonRobloxSince = -1L
        catchConfirmed = false
        catchClearFrames = 0
    }

    /** One evaluation per frame. */
    fun update(e: Evidence) {
        val now = e.nowNs
        if (!armed && state != FishingState.IDLE && state != FishingState.EMERGENCY_STOP) {
            enter(FishingState.IDLE, now, "sessão encerrada pelo host (STOP)")
            return
        }
        if (state == FishingState.IDLE) {
            if (armed) enter(FishingState.INITIAL_PRESS, now, "START FISHING; executando press inicial de 3000ms")
            return
        }
        if (state == FishingState.EMERGENCY_STOP) return

        if (!e.captureHealthy) {
            enter(FishingState.CAPTURE_ERROR, now, "captura indisponível durante a automação")
            return
        }
        if (!e.robloxForeground || e.overlaySuspected) {
            if (nonRobloxSince < 0L) nonRobloxSince = now
            if (now - nonRobloxSince > 1_000_000_000L) {
                enter(FishingState.ROBLOX_NOT_DETECTED, now, "Roblox saiu do primeiro plano ou uma sobreposição cobriu a tela")
                nonRobloxSince = -1L
                return
            }
        } else nonRobloxSince = -1L

        // Do not call an empty SHAKE search "vision lost": the prompt may appear later. The
        // confidence watchdog applies only while a minigame is expected to be visible.
        val minigameExpected = state.controlling || state == FishingState.FISHING_MINIGAME_DETECTED ||
            state == FishingState.CATCH_CONFIRMATION
        if (minigameExpected && state != FishingState.VISION_LOST) {
            val visionMissing = e.globalConf < globalConfFloor && !e.bar && !e.shake
            if (visionMissing) {
                if (noEvidenceSince < 0L) noEvidenceSince = now
                if (now - noEvidenceSince > cfg.visionLostAfterMs * 1_000_000L) {
                    enter(FishingState.VISION_LOST, now, "minigame evidence missing for ${cfg.visionLostAfterMs}ms")
                    noEvidenceSince = -1L
                    return
                }
            } else noEvidenceSince = -1L
        }

        if (state.isError) {
            // INPUT_ERROR is deliberately latched until STOP/restart; never imply that a refused
            // gesture eventually succeeded. Other transient visual/foreground errors may recover.
            if (state != FishingState.INPUT_ERROR && state != FishingState.EMERGENCY_STOP &&
                e.captureHealthy && e.robloxForeground && !e.overlaySuspected && (e.bar || e.shake)
            ) {
                enter(FishingState.RESET, now, "visual/foreground conditions recovered")
            }
            return
        }

        when (state) {
            FishingState.IDLE -> Unit

            FishingState.INITIAL_PRESS -> {
                when {
                    e.initialPressFailed -> enter(FishingState.INPUT_ERROR, now, "REAL_INPUT initial press was refused or interrupted")
                    e.initialPressComplete -> {
                        barStreak = 0
                        barLostStreak = 0
                        enter(FishingState.SEARCHING_SHAKE, now, "3000ms press completed; starting SHAKE search")
                    }
                }
            }

            FishingState.SEARCHING_SHAKE -> {
                if (e.shake) {
                    enter(FishingState.PRESSING_SHAKE, now, "SHAKE prompt detected conf=%.2f".format(e.shakeConf))
                } else if (e.bar) {
                    barStreak++
                    if (barStreak >= cfg.minigameEnterFrames) {
                        barStreak = 0
                        enter(FishingState.FISHING_MINIGAME_DETECTED, now, "minigame appeared without a SHAKE prompt")
                    }
                } else barStreak = 0
            }

            FishingState.PRESSING_SHAKE -> {
                if (e.shake) {
                    barLostStreak = 0
                } else {
                    barLostStreak++
                    if (e.bar) {
                        barStreak++
                        if (barStreak >= cfg.minigameEnterFrames) {
                            barStreak = 0
                            barLostStreak = 0
                            enter(FishingState.FISHING_MINIGAME_DETECTED, now, "SHAKE terminou e o minigame começou")
                        }
                    } else barStreak = 0
                    if (state == FishingState.PRESSING_SHAKE && (e.shakeGone || barLostStreak >= 4)) {
                        barLostStreak = 0
                        shakeSession++
                        enter(FishingState.SEARCHING_SHAKE, now, "SHAKE sumiu; retomando busca (sessão $shakeSession)")
                    }
                }
            }

            FishingState.FISHING_MINIGAME_DETECTED -> {
                if (e.fishOk && e.playerOk) enter(FishingState.TRACKING_FISH, now, "trackers prontos")
                else if (now - enteredAtNs > 700_000_000L) enter(FishingState.TRACKING_FISH, now, "iniciando tracking após espera segura")
                if (!e.bar) {
                    barLostStreak++
                    if (barLostStreak >= cfg.minigameExitFrames) {
                        barLostStreak = 0
                        toCatchOrReset(e, now)
                    }
                } else barLostStreak = 0
            }

            FishingState.TRACKING_FISH -> enter(FishingState.CONTROLLING_PLAYER_BAR, now, "tracking → controle")

            FishingState.CONTROLLING_PLAYER_BAR -> {
                if (!e.bar) {
                    barLostStreak++
                    if (barLostStreak >= cfg.minigameExitFrames) {
                        barLostStreak = 0
                        toCatchOrReset(e, now)
                    }
                } else {
                    barLostStreak = 0
                    if (now - enteredAtNs > 180_000_000_000L) {
                        enter(FishingState.INVALID_STATE, now, "minigame excedeu 180s")
                    }
                }
            }

            FishingState.CATCH_CONFIRMATION -> {
                if (e.catchConfirm && e.catchConfirmConf >= 0.50f) {
                    catchConfirmed = true
                    catchClearFrames = 0
                    enter(FishingState.RESET, now, "confirmação visual da captura")
                } else if (now - enteredAtNs > cfg.confirmWindowMs * 1_000_000L) {
                    enter(FishingState.VISION_LOST, now, "confirmação da captura não foi observada; sem press suposto")
                }
            }

            FishingState.RESET -> {
                val dwellComplete = now - enteredAtNs >= cfg.resetDwellMs * 1_000_000L
                if (!catchConfirmed && dwellComplete) {
                    enter(FishingState.INITIAL_PRESS, now, "reset concluído; novo ciclo com press de 3000ms")
                } else if (catchConfirmed) {
                    catchClearFrames = if (e.catchConfirm) 0 else catchClearFrames + 1
                    if (dwellComplete && catchClearFrames >= 2) {
                        catchConfirmed = false
                        enter(FishingState.INITIAL_PRESS, now, "aviso de captura desapareceu; novo ciclo")
                    }
                }
            }

            else -> enter(FishingState.INVALID_STATE, now, "estado não tratado")
        }
    }

    private fun toCatchOrReset(e: Evidence, now: Long) {
        val winning = e.progress >= cfg.catchMinProgress || e.catchConfirm
        if (winning) enter(FishingState.CATCH_CONFIRMATION, now, "barra sumiu com progresso=%.2f".format(max(0f, e.progress)))
        else enter(FishingState.RESET, now, "barra sumiu sem evidência de captura")
    }

    companion object {
        fun clampDt(prev: Long, now: Long): Float =
            if (prev <= 0L) 1f / 30f else min(0.25f, max(0.0005f, (now - prev) / 1e9f))
    }
}
