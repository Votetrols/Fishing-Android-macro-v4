package com.fischa.core.state

/**
 * Explicit states for the requested flow. The first action is a bounded three-second press;
 * only after its completion does visual processing look for SHAKE.
 */
enum class FishingState {
    IDLE,
    INITIAL_PRESS,
    SEARCHING_SHAKE,
    PRESSING_SHAKE,
    FISHING_MINIGAME_DETECTED,
    TRACKING_FISH,
    CONTROLLING_PLAYER_BAR,
    CATCH_CONFIRMATION,
    RESET,

    // Error/safety states
    VISION_LOST,
    CAPTURE_ERROR,
    ROBLOX_NOT_DETECTED,
    INPUT_ERROR,
    INVALID_STATE,
    EMERGENCY_STOP;

    val isError: Boolean
        get() = this == VISION_LOST || this == CAPTURE_ERROR || this == ROBLOX_NOT_DETECTED ||
            this == INPUT_ERROR || this == INVALID_STATE || this == EMERGENCY_STOP

    /** States in which the input gate may authorize a gesture. */
    val actionable: Boolean
        get() = this == INITIAL_PRESS || this == PRESSING_SHAKE || this == FISHING_MINIGAME_DETECTED ||
            this == TRACKING_FISH || this == CONTROLLING_PLAYER_BAR

    /** States where the minigame controller runs. */
    val controlling: Boolean
        get() = this == FISHING_MINIGAME_DETECTED || this == TRACKING_FISH || this == CONTROLLING_PLAYER_BAR
}

/** Evidence measured from one processed frame; no rod-button signal exists in this flow. */
data class StateEvidence(
    val shake: Boolean,
    val shakeConf: Float,
    val shakeGone: Boolean = false,
    /** minigame bar detected in this frame */
    val bar: Boolean,
    val barConf: Float,
    val progressPresent: Boolean,
    val progressValue: Float,
    val catchConfirm: Boolean,
    val catchConfirmConf: Float,
    val robloxForeground: Boolean,
    val captureHealthy: Boolean,
    val globalConfidence: Float,
    val trackingOk: Boolean,
    val overlaySuspected: Boolean,
    val frameDeltaMs: Float,
    /** Set only after the platform confirms completion of the 3000ms initial press. */
    val initialPressComplete: Boolean = false,
    /** A refused/cancelled initial press is an error, never a successful search transition. */
    val initialPressFailed: Boolean = false,
)

class StateChange(val from: FishingState, val to: FishingState, val reason: String, val timestampNs: Long)
