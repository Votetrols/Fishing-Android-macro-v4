package com.fischa.core.tools

import com.fischa.core.config.AppConfig
import com.fischa.core.control.InitialPressController
import com.fischa.core.control.TimedPressPlan
import com.fischa.core.safety.DenyReason
import com.fischa.core.safety.GestureAction
import com.fischa.core.safety.InputRequest
import com.fischa.core.safety.InputSafetyGuard
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.SafetyContext
import com.fischa.core.state.AutomationState
import com.fischa.core.state.AutomationStateMachine
import com.fischa.core.state.AutomationUi
import com.fischa.core.state.Evidence
import com.fischa.core.state.FishingState
import com.fischa.core.state.FishingStateMachine

/** Small deterministic sanity harness for the new initial-press → SHAKE lifecycle. */
object SelfTest {
    @JvmStatic
    fun main(args: Array<String>) {
        val checks = ArrayList<String>()
        fun check(name: String, condition: Boolean) {
            check(condition) { "FAIL: $name" }
            checks += name
        }

        val plan = TimedPressPlan(durationMs = 3000L, quantumMs = 65L)
        plan.start(10_000L)
        var cursor = 10_000L
        var total = 0L
        while (true) {
            val segment = plan.nextSegmentMs(cursor) ?: break
            total += segment
            cursor += segment
        }
        check("timed plan sums to exactly 3000ms", total == 3000L)
        check("timed plan completes at deadline", plan.isComplete(13_000L))

        val press = InitialPressController()
        press.startSession()
        check("initial press dispatch is one-shot", press.shouldDispatch)
        press.markDispatchAccepted()
        check("initial press waits for platform completion", !press.complete && !press.failed)
        press.onPlatformCompleted(true)
        check("initial press completes only on platform callback", press.complete)
        press.reset()
        press.startSession()
        press.markDispatchAccepted()
        press.onPlatformCompleted(false)
        check("interrupted press fails closed", press.failed)

        val machine = FishingStateMachine(AppConfig.StateTiming())
        machine.armed = true
        val e = Evidence().apply { captureHealthy = true; robloxForeground = true; globalConf = 1f }
        e.nowNs = 1_000_000_000L
        machine.update(e)
        check("START enters initial press", machine.state == FishingState.INITIAL_PRESS)
        e.initialPressComplete = true
        e.nowNs += 33_000_000L
        machine.update(e)
        check("SHAKE search follows completed press", machine.state == FishingState.SEARCHING_SHAKE)
        e.initialPressComplete = false
        e.shake = true
        e.nowNs += 33_000_000L
        machine.update(e)
        check("visible SHAKE enters prompt-press state", machine.state == FishingState.PRESSING_SHAKE)

        val stop = EmergencyStop()
        val guard = InputSafetyGuard(AppConfig.Safety())
        val ctx = SafetyContext().apply {
            automationActive = true
            macroEnabled = true
            realInputEnabled = true
            captureHealthy = true
            robloxDetected = true
            platformAuthorized = true
            state = FishingState.INITIAL_PRESS
            controllerSafe = true
            frameTimestampNs = 5_000_000_000L
        }
        val hold = InputRequest(GestureAction.HOLD_START, 0.818f, 0.692f, 250L, 1f, "initial")
        check("authorized initial hold passes gate", guard.evaluate(ctx, hold, 5_000_000_000L, stop).allowed)
        ctx.realInputEnabled = false
        check("REAL_INPUT off blocks the hold", guard.evaluate(ctx, hold, 5_000_000_000L, stop).reason == DenyReason.REAL_INPUT_DISABLED)
        check("release remains available after safety denial", guard.evaluate(ctx, InputRequest(GestureAction.HOLD_RELEASE), 5_000_000_000L, stop).allowed)

        val automation = AutomationStateMachine(clockNs = { 0L })
        automation.setInfrastructureReady(true, "test", 1L)
        check("capture readiness does not start automation", automation.state == AutomationState.APP_READY)
        automation.startFishing("test", 2L)
        check("explicit START FISHING activates automation", automation.state == AutomationState.FISHING_ACTIVE)
        check("floating control changes to STOP", AutomationUi.buttonLabel(automation.state) == "STOP")

        println("SELFTEST PASS: ${checks.size} deterministic checks")
        checks.forEach { println("  PASS $it") }
    }
}
