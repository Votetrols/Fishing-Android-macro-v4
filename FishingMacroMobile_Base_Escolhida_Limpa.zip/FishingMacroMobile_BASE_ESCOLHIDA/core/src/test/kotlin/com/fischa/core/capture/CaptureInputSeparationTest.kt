package com.fischa.core.capture

import com.fischa.core.config.AppConfig
import com.fischa.core.control.InputExecutor
import com.fischa.core.log.NoopSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.pipeline.PipelineInput
import com.fischa.core.pipeline.VisionPipeline
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.state.FishingState
import com.fischa.core.vision.VisionFrame
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class CaptureInputSeparationTest {
    @Test
    fun unhealthyCaptureNeverReachesTheInputExecutor() {
        var now = 7_000_000_000L
        var holdCalls = 0
        val executor = object : InputExecutor {
            override fun holdFor(
                nx: Float,
                ny: Float,
                durationMs: Int,
                authorize: () -> Boolean,
                onComplete: (Boolean) -> Unit,
            ): Boolean {
                holdCalls++
                if (!authorize()) return false
                onComplete(true)
                return true
            }
            override fun cancelAll() {}
        }
        val pipeline = VisionPipeline(
            AppConfig().validate(), executor, ThrottledLog(NoopSink), emergency = EmergencyStop(), monotonicNowNs = { now },
        )
        pipeline.setInfrastructureReady(true, "capture prepared", now)
        pipeline.startFishing("test", now)
        repeat(2) { idx ->
            now += 33_000_000L
            val frame = VisionFrame.allocate(96, 54).apply {
                argb.fill(0xFF777777.toInt())
                resetFor(now, idx.toLong() + 1L)
            }
            pipeline.onFrame(frame, PipelineInput(
                frameTimestampNs = now,
                currentTimeNs = now,
                captureHealthy = false,
                robloxDetected = true,
                inputAuthorized = true,
                macroEnabled = true,
                realInputEnabled = true,
                foregroundPackage = "com.roblox.client",
                foregroundBlockReason = "NONE",
            ))
        }
        assertEquals(FishingState.CAPTURE_ERROR, pipeline.output.state)
        assertEquals("capture loss must block platform input", 0, holdCalls)
        assertTrue(pipeline.output.stateReason.contains("captura"))
        pipeline.close()
    }
}
