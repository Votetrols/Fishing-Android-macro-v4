package com.fischa.core.pipeline

import com.fischa.core.config.AppConfig
import com.fischa.core.control.InputExecutor
import com.fischa.core.log.NoopSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.state.AutomationState
import com.fischa.core.state.FishingState
import com.fischa.core.vision.VisionFrame
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class StartFishingFlowTest {
    private class TestExecutor : InputExecutor {
        data class Press(
            val x: Float,
            val y: Float,
            val durationMs: Int,
            val completion: (Boolean) -> Unit,
        )

        val presses = ArrayList<Press>()
        val taps = ArrayList<Int>()
        var cancelled = 0
        var refuseNextPress = false

        override fun tap(nx: Float, ny: Float, durationMs: Int, authorize: () -> Boolean): Boolean {
            if (!authorize()) return false
            taps += durationMs
            return true
        }

        override fun holdFor(
            nx: Float,
            ny: Float,
            durationMs: Int,
            authorize: () -> Boolean,
            onComplete: (Boolean) -> Unit,
        ): Boolean {
            if (!authorize() || refuseNextPress) {
                refuseNextPress = false
                return false
            }
            presses += Press(nx, ny, durationMs, onComplete)
            return true
        }

        override fun cancelAll() { cancelled++ }
        fun completePress(index: Int, success: Boolean) { presses[index].completion(success) }
    }

    private class Rig(realInput: Boolean = true) {
        var nowNs = 1_000_000_000L
        val executor = TestExecutor()
        val pipeline = VisionPipeline(
            cfg = AppConfig().validate(),
            executor = executor,
            log = ThrottledLog(NoopSink),
            emergency = EmergencyStop(),
            monotonicNowNs = { nowNs },
        )
        var realInputEnabled = realInput
        var frameSerial = 0L

        init { pipeline.setInfrastructureReady(true, "capture RUNNING", nowNs) }

        fun start() { assertTrue(pipeline.startFishing("test START FISHING", nowNs)) }

        fun frame(macro: Boolean = pipeline.armed): VisionFrame {
            nowNs += 33_000_000L
            frameSerial++
            val frame = VisionFrame.allocate(128, 72)
            frame.argb.fill(0xFF777777.toInt())
            frame.resetFor(nowNs, frameSerial)
            pipeline.onFrame(
                frame,
                PipelineInput(
                    frameTimestampNs = nowNs,
                    currentTimeNs = nowNs,
                    captureHealthy = true,
                    robloxDetected = true,
                    inputAuthorized = true,
                    overlaySuspected = false,
                    macroEnabled = macro,
                    realInputEnabled = realInputEnabled,
                    foregroundPackage = "com.roblox.client",
                    foregroundActivityWindow = "test-window",
                    foregroundBlockReason = "NONE",
                ),
            )
            return frame
        }

        fun close() = pipeline.close()
    }

    @Test
    fun readyDoesNotAutomateAndInitialHoldPrecedesShakeSearch() {
        val rig = Rig()
        val readyFrame = rig.frame(macro = false)
        assertEquals(AutomationState.APP_READY, rig.pipeline.automationState)
        assertEquals(FishingState.IDLE, rig.pipeline.output.state)
        assertTrue("READY avoids grayscale/detector work", readyFrame.gray.all { it.toInt() == 0 })
        assertTrue(rig.executor.presses.isEmpty())

        rig.start()
        rig.frame()
        assertEquals(FishingState.INITIAL_PRESS, rig.pipeline.output.state)
        assertEquals(1, rig.executor.presses.size)
        val first = rig.executor.presses.single()
        assertEquals(3000, first.durationMs)
        assertEquals(AppConfig().initialPress.x, first.x, 0.0001f)
        assertEquals(AppConfig().initialPress.y, first.y, 0.0001f)
        assertEquals("RUNNING", rig.pipeline.output.initialPressPhase)
        assertFalse(rig.pipeline.output.shake.detected)
        assertTrue(rig.executor.taps.isEmpty())

        rig.executor.completePress(0, true)
        rig.frame()
        assertEquals(FishingState.SEARCHING_SHAKE, rig.pipeline.output.state)
        assertEquals("COMPLETE", rig.pipeline.output.initialPressPhase)
        assertTrue("the fixed hold is not reissued while searching", rig.executor.presses.size == 1)
        rig.close()
    }

    @Test
    fun realInputOffOrPlatformRefusalNeverCountsAsPressSuccess() {
        val disabled = Rig(realInput = false)
        disabled.start()
        disabled.frame()
        assertTrue(disabled.executor.presses.isEmpty())
        assertEquals("REAL_INPUT_DISABLED", disabled.pipeline.output.inputDeniedReason)
        disabled.frame()
        assertEquals(FishingState.INPUT_ERROR, disabled.pipeline.output.state)
        assertEquals("FAILED", disabled.pipeline.output.initialPressPhase)
        disabled.close()

        val refused = Rig()
        refused.executor.refuseNextPress = true
        refused.start()
        refused.frame()
        assertEquals("FAILED", refused.pipeline.output.initialPressPhase)
        refused.frame()
        assertEquals(FishingState.INPUT_ERROR, refused.pipeline.output.state)
        refused.close()
    }

    @Test
    fun stopInvalidatesPendingCompletionAndCleanRestartStartsFreshPress() {
        val rig = Rig()
        rig.start()
        rig.frame()
        assertEquals(1, rig.executor.presses.size)
        val staleCallback = rig.executor.presses[0].completion

        assertTrue(rig.pipeline.stopFishing("STOP", rig.nowNs))
        assertEquals(AutomationState.APP_READY, rig.pipeline.automationState)
        assertTrue(rig.executor.cancelled > 0)
        staleCallback(true) // late callback from the stopped run must not resume the state machine

        rig.start()
        rig.frame()
        assertEquals(FishingState.INITIAL_PRESS, rig.pipeline.output.state)
        assertEquals(2, rig.executor.presses.size)
        rig.executor.completePress(0, true)
        rig.frame()
        assertEquals("old callback ignored", FishingState.INITIAL_PRESS, rig.pipeline.output.state)
        rig.executor.completePress(1, true)
        rig.frame()
        assertEquals(FishingState.SEARCHING_SHAKE, rig.pipeline.output.state)
        rig.close()
    }
}
