package com.fischa.core.pipeline

import com.fischa.core.config.AppConfig
import com.fischa.core.control.InputExecutor
import com.fischa.core.log.NoopSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.safety.DenyReason
import com.fischa.core.state.AutomationState
import com.fischa.core.state.FishingState
import com.fischa.core.vision.VisionFrame
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

/** START is infrastructure-only; START FISHING owns the active vision/input lifecycle. */
class StartFishingLifecycleV12Test {
    private fun input(ts: Long, macro: Boolean = true) = PipelineInput(
        frameTimestampNs = ts,
        currentTimeNs = ts,
        captureHealthy = true,
        robloxDetected = true,
        inputAuthorized = true,
        macroEnabled = macro,
        realInputEnabled = true,
        foregroundPackage = "com.roblox.client",
        foregroundBlockReason = "NONE",
    )

    private fun frame(ts: Long): VisionFrame = VisionFrame.allocate(64, 32).apply {
        argb.fill(0xFF787878.toInt())
        resetFor(ts, ts)
    }

    @Test
    fun mainStartReadyDoesNotRunVisionOrInput() {
        val pipeline = VisionPipeline(AppConfig().validate(), InputExecutor.Noop, ThrottledLog(NoopSink))
        assertTrue(pipeline.setInfrastructureReady(true, "capture RUNNING", 1_000_000_000L))
        assertEquals(AutomationState.APP_READY, pipeline.automationState)

        val f = frame(1_033_000_000L)
        pipeline.onFrame(f, input(1_033_000_000L, macro = false))

        assertEquals(AutomationState.APP_READY, pipeline.automationState)
        assertEquals(FishingState.IDLE, pipeline.output.state)
        assertTrue("READY must not fill grayscale pixels", f.gray.all { it.toInt() == 0 })
        assertFalse(pipeline.output.inputIssued)
        pipeline.close()
    }

    @Test
    fun startFishingEnablesVisionAndStopClearsIt() {
        val pipeline = VisionPipeline(AppConfig().validate(), InputExecutor.Noop, ThrottledLog(NoopSink))
        pipeline.setInfrastructureReady(true, "capture RUNNING", 1_000_000_000L)
        assertTrue(pipeline.startFishing("test", 1_001_000_000L))
        assertEquals(AutomationState.FISHING_ACTIVE, pipeline.automationState)

        val f = frame(1_033_000_000L)
        pipeline.onFrame(f, input(1_033_000_000L))
        assertTrue("START FISHING must enter the active vision path", f.gray.any { it.toInt() != 0 })
        assertEquals(FishingState.INITIAL_PRESS, pipeline.output.state)
        assertEquals("FAILED", pipeline.output.initialPressPhase) // Noop refuses real gestures.

        assertTrue(pipeline.stopFishing("test stop", 1_034_000_000L))
        assertEquals(AutomationState.APP_READY, pipeline.automationState)
        val stoppedFrame = frame(1_066_000_000L)
        pipeline.onFrame(stoppedFrame, input(1_066_000_000L, macro = false))
        assertEquals(FishingState.IDLE, pipeline.output.state)
        assertEquals(DenyReason.AUTOMATION_NOT_ACTIVE.name, pipeline.output.inputDeniedReason)
        assertTrue("STOP returns to the O(1) inactive path", stoppedFrame.gray.all { it.toInt() == 0 })
        pipeline.close()
    }

}
