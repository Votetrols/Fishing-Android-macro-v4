package com.fischa.core.pipeline

import com.fischa.core.config.AppConfig
import com.fischa.core.control.InputExecutor
import com.fischa.core.log.NoopSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.state.FishingState
import com.fischa.core.vision.VisionFrame
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

/** Regression checks for fixed-duration initial input and normalized touch targeting. */
class StartSemanticsV5Test {
    @Test
    fun initialActionIsAlways3000msAndUsesConfiguredNormalizedPoint() {
        var now = 4_000_000_000L
        var observedX = Float.NaN
        var observedY = Float.NaN
        var observedDuration = 0
        val executor = object : InputExecutor {
            override fun holdFor(
                nx: Float,
                ny: Float,
                durationMs: Int,
                authorize: () -> Boolean,
                onComplete: (Boolean) -> Unit,
            ): Boolean {
                if (!authorize()) return false
                observedX = nx
                observedY = ny
                observedDuration = durationMs
                onComplete(true)
                return true
            }
            override fun cancelAll() {}
        }
        val config = AppConfig().copy(
            initialPress = AppConfig.InitialPress(0.25f, 0.75f),
            // The historical cast duration is not allowed to alter the requested fixed 3s action.
            cast = AppConfig.Cast(holdMs = 500L),
        ).validate()
        val pipeline = VisionPipeline(config, executor, ThrottledLog(NoopSink), emergency = EmergencyStop(), monotonicNowNs = { now })
        pipeline.setInfrastructureReady(true, "capture", now)
        assertTrue(pipeline.startFishing("operator", now))

        now += 33_000_000L
        val frame = VisionFrame.allocate(96, 54).apply {
            argb.fill(0xFF707070.toInt())
            resetFor(now, 1L)
        }
        pipeline.onFrame(frame, PipelineInput(
            frameTimestampNs = now,
            currentTimeNs = now,
            captureHealthy = true,
            robloxDetected = true,
            inputAuthorized = true,
            macroEnabled = true,
            realInputEnabled = true,
            foregroundPackage = "com.roblox.client",
            foregroundBlockReason = "NONE",
        ))

        assertEquals(FishingState.INITIAL_PRESS, pipeline.output.state)
        assertEquals(0.25f, observedX, 0f)
        assertEquals(0.75f, observedY, 0f)
        assertEquals(3000, observedDuration)
        pipeline.close()
    }
}
