package com.fischa.core.safety

import com.fischa.core.config.AppConfig
import com.fischa.core.state.FishingState
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class InputSafetyGuardTest {
    private val now = 9_000_000_000L
    private val config = AppConfig().validate()
    private val guard = InputSafetyGuard(config.safety)
    private val hold = InputRequest(GestureAction.HOLD_START, 0.818f, 0.692f, config.safety.maxHoldLeaseMs, 0.95f, "initial press")

    private fun context(state: FishingState = FishingState.INITIAL_PRESS) = SafetyContext().apply {
        automationActive = true
        macroEnabled = true
        realInputEnabled = true
        captureHealthy = true
        robloxDetected = true
        platformAuthorized = true
        overlaySuspected = false
        this.state = state
        targetConfidence = 0.95f
        trackingOk = true
        controllerSafe = true
        frameTimestampNs = now
    }

    private fun deny(c: SafetyContext, request: InputRequest = hold, emergency: EmergencyStop = EmergencyStop()) =
        guard.evaluate(c, request, now, emergency)

    @Test
    fun validInitialHoldPassesWithoutMinigameTrackers() {
        val ctx = context().apply { trackingOk = false }
        assertTrue(deny(ctx).allowed)
    }

    @Test
    fun requiredSafetyConditionsBlock() {
        assertEquals(DenyReason.AUTOMATION_NOT_ACTIVE, deny(context().apply { automationActive = false }).reason)
        assertEquals(DenyReason.MACRO_DISABLED, deny(context().apply { macroEnabled = false }).reason)
        assertEquals(DenyReason.REAL_INPUT_DISABLED, deny(context().apply { realInputEnabled = false }).reason)
        assertEquals(DenyReason.CAPTURE_STOPPED, deny(context().apply { captureHealthy = false }).reason)
        assertEquals(DenyReason.ROBLOX_NOT_DETECTED, deny(context().apply { robloxDetected = false }).reason)
        assertEquals(DenyReason.FOREGROUND_UNAUTHORIZED, deny(context().apply { platformAuthorized = false }).reason)
        assertEquals(DenyReason.OVERLAY_ACTIVE, deny(context().apply { overlaySuspected = true }).reason)
        assertEquals(DenyReason.STATE_NOT_ACTIONABLE, deny(context(FishingState.IDLE)).reason)
        assertEquals(DenyReason.CONTROLLER_UNSAFE, deny(context().apply { controllerSafe = false }).reason)
        assertEquals(
            DenyReason.TRACKING_LOST,
            deny(context(FishingState.CONTROLLING_PLAYER_BAR).apply { trackingOk = false }).reason,
        )
    }

    @Test
    fun staleFramesLowConfidenceAndInvalidCommandsBlock() {
        val stale = context().apply { frameTimestampNs = now - (config.safety.maxFrameAgeMs + 5) * 1_000_000L }
        assertEquals(DenyReason.FRAME_STALE, deny(stale).reason)
        assertEquals(DenyReason.TARGET_CONFIDENCE_LOW, deny(context(), hold.copy(confidence = 0.1f)).reason)
        assertEquals(DenyReason.COORDINATES_OUT_OF_BOUNDS, deny(context(), hold.copy(nx = Float.NaN)).reason)
        assertEquals(DenyReason.COORDINATES_OUT_OF_BOUNDS, deny(context(), hold.copy(nx = 1.1f)).reason)
        assertEquals(DenyReason.INVALID_DURATION, deny(context(), hold.copy(durationMs = 0L)).reason)
        assertEquals(DenyReason.RATE_LIMITED, deny(context().apply { lastInputNs = now - 5_000_000L }).reason)
    }

    @Test
    fun emergencyBlocksNewGestureButNeverBlocksCleanup() {
        val emergency = EmergencyStop().apply { activate("test") }
        assertEquals(DenyReason.EMERGENCY_STOP, deny(context(), hold, emergency).reason)
        assertTrue(deny(context().apply { realInputEnabled = false }, InputRequest(GestureAction.HOLD_RELEASE), emergency).allowed)
        assertTrue(deny(context(), InputRequest(GestureAction.CANCEL_ALL), emergency).allowed)
    }
}
