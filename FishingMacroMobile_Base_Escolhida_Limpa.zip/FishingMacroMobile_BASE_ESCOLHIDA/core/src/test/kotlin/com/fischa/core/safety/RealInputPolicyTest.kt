package com.fischa.core.safety

import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class RealInputPolicyTest {
    @Test
    fun realInputRequiresBothSessionOptInAndConnectedAccessibilityService() {
        assertFalse(RealInputPolicy.allows(sessionAuthorized = false, accessibilityServiceConnected = false))
        assertFalse(RealInputPolicy.allows(sessionAuthorized = false, accessibilityServiceConnected = true))
        assertFalse(RealInputPolicy.allows(sessionAuthorized = true, accessibilityServiceConnected = false))
        assertTrue(RealInputPolicy.allows(sessionAuthorized = true, accessibilityServiceConnected = true))
    }
}
