package com.fischa.core.state

import com.fischa.core.config.AppConfig
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class FishingStateMachineTest {
    private fun evidence(now: Long, block: Evidence.() -> Unit = {}) = Evidence().apply {
        robloxForeground = true
        captureHealthy = true
        globalConf = 0.9f
        nowNs = now
        block()
    }

    @Test
    fun initialPressMustCompleteBeforeShakeSearch() {
        val machine = FishingStateMachine(AppConfig.StateTiming())
        machine.armed = true
        var now = 1_000_000_000L
        machine.update(evidence(now))
        assertEquals(FishingState.INITIAL_PRESS, machine.state)

        now += 33_000_000L
        machine.update(evidence(now) { shake = true; shakeConf = 0.95f })
        assertEquals("SHAKE cannot skip the 3s press completion", FishingState.INITIAL_PRESS, machine.state)

        now += 33_000_000L
        machine.update(evidence(now) { initialPressComplete = true; shake = true; shakeConf = 0.95f })
        assertEquals(FishingState.SEARCHING_SHAKE, machine.state)

        now += 33_000_000L
        machine.update(evidence(now) { shake = true; shakeConf = 0.95f })
        assertEquals(FishingState.PRESSING_SHAKE, machine.state)
    }

    @Test
    fun refusedOrInterruptedPressLatchesInputErrorUntilNewSession() {
        val machine = FishingStateMachine(AppConfig.StateTiming())
        machine.armed = true
        var now = 2_000_000_000L
        machine.update(evidence(now))
        assertEquals(FishingState.INITIAL_PRESS, machine.state)

        now += 33_000_000L
        machine.update(evidence(now) { initialPressFailed = true; shake = true; shakeConf = 0.99f })
        assertEquals(FishingState.INPUT_ERROR, machine.state)
        assertTrue(machine.state.isError)

        now += 2_000_000_000L
        machine.update(evidence(now) { initialPressComplete = true; shake = true; shakeConf = 0.99f })
        assertEquals("a late success callback cannot clear INPUT_ERROR", FishingState.INPUT_ERROR, machine.state)

        machine.disarm(now, "STOP")
        assertEquals(FishingState.IDLE, machine.state)
        machine.armed = true
        machine.update(evidence(now + 33_000_000L))
        assertEquals(FishingState.INITIAL_PRESS, machine.state)
    }

    @Test
    fun shakeSearchAllowsBarBasedMinigameEntry() {
        val machine = FishingStateMachine(AppConfig.StateTiming(minigameEnterFrames = 2))
        machine.armed = true
        var now = 3_000_000_000L
        machine.update(evidence(now))
        now += 33_000_000L
        machine.update(evidence(now) { initialPressComplete = true })
        assertEquals(FishingState.SEARCHING_SHAKE, machine.state)

        repeat(2) {
            now += 33_000_000L
            machine.update(evidence(now) { bar = true; barConf = 0.9f })
        }
        assertEquals(FishingState.FISHING_MINIGAME_DETECTED, machine.state)
        assertFalse(machine.shakePhaseActive())
    }
}
