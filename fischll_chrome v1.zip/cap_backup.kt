package com.fischa.core.capture

import com.fischa.core.config.AppConfig
import com.fischa.core.log.NoopSink
import com.fischa.core.log.ThrottledLog
import com.fischa.core.pipeline.PipelineInput
import com.fischa.core.pipeline.VisionPipeline
import com.fischa.core.safety.EmergencyStop
import com.fischa.core.safety.RealInputPolicy
import com.fischa.core.safety.RobloxForegroundStatus
import com.fischa.core.scene.ShakeSceneFixture
import com.fischa.core.state.FishingState
import com.fischa.core.vision.VisionFrame
import com.fischa.core.control.InputExecutor
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test

/**
 * V13 — separação captura / input: a captura alimenta a visão, mas só um cast com todas as
 * pré-condições gera gesto. Sem vara: a única entrada de cast é a ROI manual.
 */
class CaptureInputSeparationTest {

    private class Recorder : InputExecutor {
        var gestures = 0
        override fun tap(nx: Float, ny: Float, durationMs: Int) {}
        override fun tap(nx: Float, ny: Float, durationMs: Int, authorize: () -> Boolean): Boolean {
            if (!authorize()) return false
            gestures++; return true
        }
        override fun holdStart(nx: Float, ny: Float, leaseMs: Int, authorize: () -> Boolean): Boolean {
            if (!authorize()) return false
            gestures++; return true
        }
        override fun holdExtend(nx: Float, ny: Float, leaseMs: Int, authorize: () -> Boolean): Boolean {
            if (!authorize()) return false
            gestures++; return true
        }
        override fun holdRelease() {}
        override fun cancelAll() {}
    }

    private val cfg = AppConfig().copy(
        cast = AppConfig.Cast(roiConfigured = true, roiX = 0.62f, roiY = 0.47f, roiWidth = 0.32f, roiHeight = 0.36f),
    ).validate()

    @Before fun unlock() = RealInputPolicy.unlockForTesting("V13 capture/input separation")
    @After fun lock() = RealInputPolicy.lock()

    private fun run(realInput: Boolean, captureHealthy: Boolean, frames: Int = 10): Pair<Recorder, FishingState> {
        val rec = Recorder()
        var now = 1_000_000_000L
        val pipeline = VisionPipeline(
            cfg = cfg,
            executor = rec,
            log = ThrottledLog(NoopSink),
            emergency = EmergencyStop(),
            foregroundStatusProvider = {
                RobloxForegroundStatus(
                    foregroundPackage = "com.roblox.client",
                    robloxDetected = true,
                    inputAuthorized = true,
                    blockReason = "NONE",
                    timestampMs = now / 1_000_000L,
                )
            },
        )
        pipeline.setInfrastructureReady(true, "captura RUNNING", now)
        pipeline.startFishing("START FISHING", now)
        repeat(frames) { i ->
            val f = VisionFrame.allocate(640, 288)
            ShakeSceneFixture.draw(f, shakePrompt = false)
            f.resetFor(now, (i + 1).toLong())
            f.ensureGray()
            pipeline.onFrame(f, PipelineInput(
                frameTimestampNs = now,
                currentTimeNs = now,
                captureHealthy = captureHealthy,
                robloxDetected = true,
                inputAuthorized = true,
                macroEnabled = true,
                realInputEnabled = realInput,
                foregroundPackage = "com.roblox.client",
                foregroundBlockReason = "NONE",
                screenWidthPx = 1080,
                screenHeightPx = 2400,
            ))
            now += 33_000_000L
        }
        val state = pipeline.output.state
        pipeline.close()
        return rec to state
    }

    @Test fun healthyCaptureWithRealInputOffNeverGesturesButStillTracksTheCycle() {
        val (rec, state) = run(realInput = false, captureHealthy = true)
        assertEquals("realInput OFF → nenhum gesto", 0, rec.gestures)
        assertEquals("o ciclo continua avaliando (IDLE, sem cast)", FishingState.IDLE, state)
    }

    @Test fun realInputOnWithHealthyCaptureCastsOnce() {
        val (rec, state) = run(realInput = true, captureHealthy = true)
        assertTrue("o cast acontece com captura saudável", rec.gestures >= 1)
        assertEquals(FishingState.CASTING, state)
    }

    @Test fun deadCaptureNeverGestures() {
        val (rec, state) = run(realInput = true, captureHealthy = false)
        assertEquals("captura morta → nenhum gesto", 0, rec.gestures)
        assertEquals(FishingState.IDLE, state)
    }
}
