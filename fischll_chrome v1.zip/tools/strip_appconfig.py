import re, sys
p = sys.argv[1]
src = open(p, encoding='utf-8').read().split('\n')
out = []
i = 0
removed = {'lines': 0}
ROD_PUT = re.compile(r'^\s*put\("(rod|rodV7|rodV8|rodButtonV9|rodDetector|state\.waitingForWaterMs|cast\.minConfidence|cast\.postCastSettleMs|cast\.pressCooldownMs|vision\.rodPrior|cast\.holdMs)')
def skip(n=1):
    removed['lines'] += n

lines = src
# --- A: enum + doc at top
start = next(k for k,l in enumerate(lines) if l.startswith('enum class RodDetectorKind'))
doc_start = next(k for k in range(start-1, -1, -1) if lines[k].strip() == '/**')
end = start
del lines[doc_start:end+1]; skip(end+1-doc_start)

# --- B: header fields rod/rodV7/rodDetector/rodV8/rodButtonV9
s = next(k for k,l in enumerate(lines) if l.strip() == 'val rod: Rod = Rod(),')
e = next(k for k,l in enumerate(lines) if l.strip().startswith('val rodButtonV9: RodButtonV9'))
del lines[s:e+1]; skip(e+1-s)
# remove the doc comment block of rodButtonV9 that starts before rodButtonV9 (already inside range)

# --- C: Vision rod button block
s = next(k for k,l in enumerate(lines) if '-- fishing (rod) button --' in l)
e = next(k for k,l in enumerate(lines) if 'val rodPriorWeight' in l)
del lines[s:e+1]; skip(e+1-s)

# --- D: Cast block (replace) + Rod/RodV7/RodV8/RodButtonV9 classes
s = next(k for k,l in enumerate(lines) if l.strip() == 'data class Cast(')
# find the end of Cast: first line '    )' after s
e = next(k for k in range(s, len(lines)) if lines[k] == '    )')
# include preceding doc comment of Cast
ds = s
while ds-1 >= 0 and (lines[ds-1].strip().startswith('*') or lines[ds-1].strip().startswith('/**')) :
    ds -= 1
NEW_CAST = '''    /**
     * Cast do VARAR (V13). O cast NÃO usa detecção visual: o toque acontece no centro da ROI manual
     * já configurada ([roiX]/[roiY]/[roiWidth]/[roiHeight], coordenadas normalizadas da tela), é
     * mantido por [holdMs] (CAST_HOLD_DURATION_MS) e termina com release seguro.
     */
    data class Cast(
        /** CAST_HOLD_DURATION_MS — duração do pressionar-e-segurar do cast, em ms. */
        val holdMs: Long = 3000,
        /** Verdadeiro somente após o usuário salvar a ROI manual do VARAR (pré-requisito do cast). */
        val roiConfigured: Boolean = false,
        /** Canto superior esquerdo da ROI manual do VARAR (fração da tela). */
        val roiX: Float = 0.62f,
        val roiY: Float = 0.47f,
        val roiWidth: Float = 0.32f,
        val roiHeight: Float = 0.36f,
    )
'''.split('\n')[:-1]
del lines[ds:e+1]; skip(e+1-ds)
lines[ds:ds] = NEW_CAST
# Rod ... RodButtonV9 classes: from the '/**' that precedes 'data class Rod(' to line before 'data class StateTiming('
s = next(k for k,l in enumerate(lines) if l.strip() == 'data class Rod(')
while not lines[s].strip() == '/**': s -= 1
e = next(k for k,l in enumerate(lines) if l.strip() == 'data class StateTiming(')
while not lines[e-1].strip() == '' : e -= 1  # keep the blank line before StateTiming
# remove from s up to e-1 (blank line kept by 'e')
del lines[s:e]; skip(e-s)

# --- E: StateTiming waitingForWaterMs (doc + value)
s = next(k for k,l in enumerate(lines) if 'waitingForWaterMs: Long' in l)
ds = s
while lines[ds-1].strip().startswith('/**') or lines[ds-1].strip().startswith('*') or lines[ds-1].strip().startswith('/*'):
    ds -= 1
del lines[ds:s+1]; skip(s+1-ds)
ins = next(k for k,l in enumerate(lines) if 'val idleAutoArm' in l)
lines[ins:ins] = [
 '        /** Watchdog do CASTING: se o hold não terminar neste prazo, o ciclo vai para RESET. */',
 '        val castTimeoutMs: Long = 8_000,'
]

# --- F: validate()
lines = [l for l in lines if not re.match(r'^\s*require\(vision\.rodPrior', l)]
s = next(k for k,l in enumerate(lines) if 'require(cast.holdMs in 500..5000)' in l)
e = next(k for k,l in enumerate(lines) if 'require(cast.pressCooldownMs' in l)
lines[s:e+1] = [
 '        require(cast.holdMs in 500..5000)',
 '        require(cast.roiX.isFinite() && cast.roiX in 0f..1f)',
 '        require(cast.roiY.isFinite() && cast.roiY in 0f..1f)',
 '        require(cast.roiWidth.isFinite() && cast.roiWidth in 0.02f..1f)',
 '        require(cast.roiHeight.isFinite() && cast.roiHeight in 0.02f..1f)',
 '        require(cast.roiX + cast.roiWidth <= 1.0001f && cast.roiY + cast.roiHeight <= 1.0001f)',
]
s = next(k for k,l in enumerate(lines) if 'require(rod.confirmFrames' in l)
e = next(k for k,l in enumerate(lines) if 'require(rod.confirmWindowMs' in l)
del lines[s:e+1]; skip(e+1-s)
lines = [l for l in lines if 'require(state.waitingForWaterMs' not in l]
s = next(k for k,l in enumerate(lines) if 'require(rodV7.maxRefinedCandidates' in l)
e = next(k for k,l in enumerate(lines) if l.strip() == 'return this')
del lines[s:e]; skip(e-s)
ins = next(k for k,l in enumerate(lines) if 'require(state.resetDwellMs' in l)
lines.insert(ins+1, '        require(state.castTimeoutMs in 1_000..60_000)')
lines.insert(ins+2, '        require(state.castTimeoutMs > cast.holdMs)')

# --- G: toMap
out=[]
for l in lines:
    if ROD_PUT.match(l):
        if 'cast.holdMs' in l:
            out.append(l); continue
        skip(1); continue
    out.append(l)
lines = out
ins = next(k for k,l in enumerate(lines) if 'put("cast.holdMs"' in l)
lines[ins+1:ins+1] = [
 '        put("cast.roiConfigured", cast.roiConfigured.toString())',
 '        put("cast.roiX", cast.roiX.toString())',
 '        put("cast.roiY", cast.roiY.toString())',
 '        put("cast.roiWidth", cast.roiWidth.toString())',
 '        put("cast.roiHeight", cast.roiHeight.toString())',
 '        put("state.castTimeoutMs", state.castTimeoutMs.toString())',
]

# --- H: withOverrides
out=[]
i=0
while i < len(lines):
    l = lines[i]
    if re.match(r'^\s*(rodPriorCx|rodPriorCy|rodSearchX0|rodSearchX1|rodSearchY0|rodSearchY1)\s*=', l):
        skip(1); i+=1; continue
    m = re.match(r'^(\s*)(rod|rodV7|rodV8|rodButtonV9) = \w+\.copy\($', l)
    if m:
        ind = m.group(1)
        j = i+1
        while not (lines[j] == ind + '),'): j+=1
        skip(j-i+1); i = j+1; continue
    if re.match(r'^\s*rodDetector = map\["rodDetector"\]', l):
        skip(3); i += 3; continue
    if l.strip() == 'cast = cast.copy(' or l.strip().startswith('cast = cast.copy('):
        ind = l[:len(l)-len(l.lstrip())]
        j=i+1
        while lines[j] != ind + '),': j+=1
        skip(j-i+1)
        out.append(ind + 'cast = cast.copy(')
        out.append(ind + '    holdMs = l("cast.holdMs", cast.holdMs),')
        out.append(ind + '    roiConfigured = map["cast.roiConfigured"]?.toBooleanStrictOrNull()')
        out.append(ind + '        ?: map["rodButtonV9.manualRoiEnabled"]?.toBooleanStrictOrNull() ?: cast.roiConfigured,')
        out.append(ind + '    roiX = f("cast.roiX", f("rodButtonV9.initialRoiX", cast.roiX)),')
        out.append(ind + '    roiY = f("cast.roiY", f("rodButtonV9.initialRoiY", cast.roiY)),')
        out.append(ind + '    roiWidth = f("cast.roiWidth", f("rodButtonV9.roiWidth", cast.roiWidth)),')
        out.append(ind + '    roiHeight = f("cast.roiHeight", f("rodButtonV9.roiHeight", cast.roiHeight)),')
        out.append(ind + '),')
        i = j+1; continue
    if re.match(r'^\s*state = state\.copy\($', l):
        ind = l[:len(l)-len(l.lstrip())]
        j=i+1
        while lines[j] != ind + '),': j+=1
        skip(j-i+1)
        out.append(ind + 'state = state.copy(')
        out.append(ind + '    castTimeoutMs = l("state.castTimeoutMs", state.castTimeoutMs),')
        out.append(ind + '),')
        i=j+1; continue
    out.append(l); i+=1
lines = out
open(p,'w',encoding='utf-8').write('\n'.join(lines))
print('removed lines (approx):', removed['lines'])
